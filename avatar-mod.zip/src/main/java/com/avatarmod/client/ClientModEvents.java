package com.avatarmod.client;

import com.avatarmod.AvatarMod;
import com.avatarmod.bending.Element;
import com.avatarmod.entity.ModEntities;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.client.renderer.entity.VillagerRenderer;
import net.minecraft.world.entity.npc.Villager;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AvatarMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(ModKeys.MENU);
        event.register(ModKeys.MODE);
        event.register(ModKeys.NEXT);
        event.register(ModKeys.PREVIOUS);
    }

    @SubscribeEvent
    public static void onRegisterOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("bending_bar",
                (gui, graphics, partialTick, width, height) -> BendingHud.render(graphics, width, height));
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        // Водяной и огненный шары пока рисуются только частицами. Позже сюда можно подключить модели из Blockbench.
        event.registerEntityRenderer(ModEntities.WATER_BALL.get(), NoopRenderer::new);
        event.registerEntityRenderer(ModEntities.FIRE_BALL.get(), NoopRenderer::new);
        event.registerEntityRenderer(ModEntities.EARTH_BOULDER.get(), EarthBoulderRenderer::new);

        for (Element element : Element.values()) {
            event.<Villager>registerEntityRenderer(ModEntities.TEACHERS.get(element).get(), VillagerRenderer::new);
            event.registerEntityRenderer(ModEntities.BOSSES.get(element).get(),
                    context -> new ElementBossRenderer(context, element));
        }
    }
}
