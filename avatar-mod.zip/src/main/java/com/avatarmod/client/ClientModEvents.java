package com.avatarmod.client;

import com.avatarmod.AvatarMod;
import com.avatarmod.entity.ModEntities;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AvatarMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(ModKeys.CAST);
        event.register(ModKeys.NEXT);
        event.register(ModKeys.PREVIOUS);
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        // Водяной и огненный шары пока рисуются только частицами. Позже сюда можно подключить модели из Blockbench.
        event.registerEntityRenderer(ModEntities.WATER_BALL.get(), NoopRenderer::new);
        event.registerEntityRenderer(ModEntities.FIRE_BALL.get(), NoopRenderer::new);
        event.registerEntityRenderer(ModEntities.EARTH_BOULDER.get(), EarthBoulderRenderer::new);
    }
}
