package com.avatarmod.client;

import com.avatarmod.AvatarMod;
import com.avatarmod.entity.ElementTeacherEntity;
import com.avatarmod.network.AbilityPacket;
import com.avatarmod.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AvatarMod.MODID, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {}

    private static void send(AbilityPacket.Action action) {
        ModNetwork.CHANNEL.sendToServer(new AbilityPacket(action));
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        while (ModKeys.MENU.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new BendingScreen());
        }
        while (ModKeys.MODE.consumeClick()) {
            toggleMode(mc);
        }
        while (ModKeys.NEXT.consumeClick()) {
            send(AbilityPacket.Action.NEXT);
        }
        while (ModKeys.PREVIOUS.consumeClick()) {
            send(AbilityPacket.Action.PREVIOUS);
        }
    }

    private static void toggleMode(Minecraft mc) {
        if (ClientProgress.unlockedAbilities().isEmpty()) {
            mc.player.displayClientMessage(Component.translatable("message.avatarmod.no_abilities"), true);
            return;
        }
        ClientProgress.bendingMode = !ClientProgress.bendingMode;
        mc.player.displayClientMessage(Component.translatable(
                ClientProgress.bendingMode ? "message.avatarmod.mode_on" : "message.avatarmod.mode_off"), true);
    }

    /** В режиме покорения правая кнопка мыши применяет способность вместо обычного использования. */
    @SubscribeEvent
    public static void onUseKey(InputEvent.InteractionKeyMappingTriggered event) {
        if (!event.isUseItem() || !ClientProgress.bendingMode) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) return;
        // Учителей можно по-прежнему торговать правой кнопкой.
        if (mc.crosshairPickEntity instanceof ElementTeacherEntity) return;
        if (ClientProgress.unlockedAbilities().isEmpty()) return;

        event.setCanceled(true);
        event.setSwingHand(true);
        send(AbilityPacket.Action.CAST);
    }

    /** В режиме покорения колесо мыши листает способности вместо слотов хотбара. */
    @SubscribeEvent
    public static void onScroll(InputEvent.MouseScrollingEvent event) {
        if (!ClientProgress.bendingMode) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) return;
        double delta = event.getScrollDelta();
        if (delta == 0.0) return;

        event.setCanceled(true);
        send(delta < 0.0 ? AbilityPacket.Action.NEXT : AbilityPacket.Action.PREVIOUS);
    }
}
