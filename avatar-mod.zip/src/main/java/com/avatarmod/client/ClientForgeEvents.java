package com.avatarmod.client;

import com.avatarmod.AvatarMod;
import com.avatarmod.network.AbilityPacket;
import com.avatarmod.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AvatarMod.MODID, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (Minecraft.getInstance().player == null) return;

        while (ModKeys.CAST.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new AbilityPacket(AbilityPacket.Action.CAST));
        }
        while (ModKeys.NEXT.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new AbilityPacket(AbilityPacket.Action.NEXT));
        }
        while (ModKeys.PREVIOUS.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new AbilityPacket(AbilityPacket.Action.PREVIOUS));
        }
    }
}
