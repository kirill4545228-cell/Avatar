package com.avatarmod.client;

import com.avatarmod.bending.Ability;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Панель способностей справа на экране. В режиме покорения показывает список для быстрого выбора. */
public final class BendingHud {
    private static final int MAX_LINES = 9;

    private BendingHud() {}

    public static void render(GuiGraphics graphics, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || mc.screen != null) return;

        List<Ability> list = ClientProgress.unlockedAbilities();
        if (list.isEmpty()) return;
        Ability selected = ClientProgress.selected();
        if (selected == null) return;

        Font font = mc.font;
        int right = width - 8;

        if (!ClientProgress.bendingMode) {
            Component text = Component.translatable(selected.translationKey());
            graphics.drawString(font, text, right - font.width(text), height - 44, 0x999999, true);
            return;
        }

        int index = Math.max(0, list.indexOf(selected));
        int start = Math.max(0, Math.min(index - MAX_LINES / 2, list.size() - MAX_LINES));
        int end = Math.min(list.size(), start + MAX_LINES);
        int lineHeight = 11;
        int y = height / 2 - ((end - start + 1) * lineHeight) / 2;

        Component header = Component.translatable("hud.avatarmod.mode");
        graphics.drawString(font, header, right - font.width(header), y, 0xFFFFFF, true);
        y += lineHeight;

        for (int i = start; i < end; i++) {
            Ability ability = list.get(i);
            boolean current = ability == selected;
            Component text = Component.translatable(ability.translationKey() + ".short");
            if (current) {
                text = Component.literal("> ").append(text);
            }
            int color = current ? ClientProgress.colorOf(ability.element()) : 0x888888;
            graphics.drawString(font, text, right - font.width(text), y, color, true);
            y += lineHeight;
        }
    }
}
