package com.avatarmod.client;

import com.avatarmod.bending.Abilities;
import com.avatarmod.bending.Ability;
import com.avatarmod.bending.Element;
import com.avatarmod.network.ChooseElementPacket;
import com.avatarmod.network.ModNetwork;
import com.avatarmod.network.SelectAbilityPacket;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/**
 * Меню на клавише B. Новичку предлагает выбрать стихию,
 * остальным показывает способности по стихиям и позволяет выбрать нужную одним нажатием.
 */
public class BendingScreen extends Screen {
    private int columnWidth;
    private int startX;
    private static final int GAP = 6;
    private static final int TOP = 56;

    public BendingScreen() {
        super(Component.translatable("screen.avatarmod.menu"));
    }

    @Override
    protected void init() {
        if (!ClientProgress.hasChosen()) {
            initChoose();
        } else {
            initAbilities();
        }
    }

    private void initChoose() {
        int w = 140;
        int h = 20;
        int gap = 8;
        Element[] elements = Element.values();
        int x = width / 2 - w / 2;
        int y = height / 2 - (elements.length * (h + gap)) / 2 + 12;
        for (int i = 0; i < elements.length; i++) {
            Element element = elements[i];
            addRenderableWidget(Button.builder(Component.translatable(element.translationKey()), button -> {
                ModNetwork.CHANNEL.sendToServer(new ChooseElementPacket(element));
                onClose();
            }).bounds(x, y + i * (h + gap), w, h).build());
        }
    }

    private void initAbilities() {
        Element[] elements = Element.values();
        columnWidth = Math.min(110, (width - 40) / elements.length);
        int totalWidth = elements.length * columnWidth + (elements.length - 1) * GAP;
        startX = (width - totalWidth) / 2;

        for (int c = 0; c < elements.length; c++) {
            List<Ability> abilities = Abilities.ofElement(elements[c]);
            int x = startX + c * (columnWidth + GAP);
            for (int r = 0; r < abilities.size(); r++) {
                Ability ability = abilities.get(r);
                boolean unlocked = ClientProgress.isUnlocked(ability);
                boolean selected = ability == ClientProgress.selected();

                MutableComponent label = Component.translatable(ability.translationKey() + ".short");
                if (!unlocked) {
                    label = label.withStyle(ChatFormatting.DARK_GRAY);
                } else if (selected) {
                    label = Component.literal("> ").append(label).withStyle(ChatFormatting.YELLOW);
                }

                Button button = Button.builder(label, b -> {
                    ModNetwork.CHANNEL.sendToServer(new SelectAbilityPacket(ability.id()));
                    onClose();
                }).bounds(x, TOP + r * 24, columnWidth, 20).build();
                button.active = unlocked;
                addRenderableWidget(button);
            }
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        graphics.drawCenteredString(font, title, width / 2, 14, 0xFFFFFF);

        if (!ClientProgress.hasChosen()) {
            graphics.drawCenteredString(font, Component.translatable("screen.avatarmod.choose_hint"),
                    width / 2, 32, 0xAAAAAA);
        } else {
            Element[] elements = Element.values();
            for (int c = 0; c < elements.length; c++) {
                Element element = elements[c];
                int centerX = startX + c * (columnWidth + GAP) + columnWidth / 2;
                int total = Abilities.ofElement(element).size();
                Component header = Component.translatable(element.translationKey())
                        .append(" " + ClientProgress.learnedCount(element) + "/" + total);
                graphics.drawCenteredString(font, header, centerX, 26, ClientProgress.colorOf(element));

                boolean defeated = ClientProgress.isBossDefeated(element);
                graphics.drawCenteredString(font,
                        Component.translatable(defeated ? "screen.avatarmod.master_defeated"
                                : "screen.avatarmod.master_pending"),
                        centerX, 40, defeated ? 0x55FF55 : 0x888888);
            }
            graphics.drawCenteredString(font, Component.translatable("screen.avatarmod.controls"),
                    width / 2, height - 26, 0xAAAAAA);
            graphics.drawCenteredString(font, Component.translatable("screen.avatarmod.controls2"),
                    width / 2, height - 14, 0xAAAAAA);
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ModKeys.MENU.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
