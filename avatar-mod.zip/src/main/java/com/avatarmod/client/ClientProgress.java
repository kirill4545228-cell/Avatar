package com.avatarmod.client;

import com.avatarmod.bending.Abilities;
import com.avatarmod.bending.Ability;
import com.avatarmod.bending.Element;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Копия прогресса игрока на клиенте (приходит от сервера) и состояние режима покорения. */
public final class ClientProgress {
    private static boolean chosen = false;
    private static boolean avatar = false;
    private static List<String> unlocked = List.of();
    private static String selected = "";
    private static Set<String> bosses = Set.of();

    /** Режим покорения: ПКМ применяет способность, колесо мыши переключает способности. */
    public static boolean bendingMode = false;

    private ClientProgress() {}

    public static void apply(boolean chosen, boolean avatar, List<String> unlocked, String selected,
                             List<String> bosses) {
        ClientProgress.chosen = chosen;
        ClientProgress.avatar = avatar;
        ClientProgress.unlocked = List.copyOf(unlocked);
        ClientProgress.selected = selected;
        ClientProgress.bosses = new HashSet<>(bosses);
        if (unlocked.isEmpty()) {
            bendingMode = false;
        }
    }

    public static boolean hasChosen() {
        return chosen;
    }

    public static boolean isAvatar() {
        return avatar;
    }

    public static boolean isUnlocked(Ability ability) {
        return unlocked.contains(ability.id());
    }

    public static boolean isBossDefeated(Element element) {
        return bosses.contains(element.name());
    }

    public static int learnedCount(Element element) {
        int count = 0;
        for (Ability ability : Abilities.ofElement(element)) {
            if (isUnlocked(ability)) count++;
        }
        return count;
    }

    public static List<Ability> unlockedAbilities() {
        List<Ability> result = new ArrayList<>();
        for (Ability ability : Abilities.ALL) {
            if (isUnlocked(ability)) result.add(ability);
        }
        return result;
    }

    /** @return выбранная способность или null, если ничего не изучено. */
    public static Ability selected() {
        Ability ability = Abilities.byId(selected);
        if (ability != null && isUnlocked(ability)) return ability;
        List<Ability> list = unlockedAbilities();
        return list.isEmpty() ? null : list.get(0);
    }

    public static int colorOf(Element element) {
        return switch (element) {
            case WATER -> 0x55AAFF;
            case AIR -> 0xE0E8F0;
            case EARTH -> 0xC09A5A;
            case FIRE -> 0xFF7733;
        };
    }
}
