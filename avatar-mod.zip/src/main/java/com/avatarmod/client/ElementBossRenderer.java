package com.avatarmod.client;

import com.avatarmod.AvatarMod;
import com.avatarmod.bending.Element;
import com.avatarmod.entity.ElementBossEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Мастер стихии: гуманоид в цвете своей стихии. Позже можно заменить моделью из Blockbench. */
public class ElementBossRenderer extends HumanoidMobRenderer<ElementBossEntity, HumanoidModel<ElementBossEntity>> {
    private final ResourceLocation texture;

    public ElementBossRenderer(EntityRendererProvider.Context context, Element element) {
        super(context, new HumanoidModel<ElementBossEntity>(context.bakeLayer(ModelLayers.PLAYER)), 0.6F);
        this.texture = new ResourceLocation(AvatarMod.MODID, "textures/entity/boss_" + element.key() + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(ElementBossEntity entity) {
        return texture;
    }

    @Override
    protected void scale(ElementBossEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.25F, 1.25F, 1.25F);
    }
}
