package com.avatarmod.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;

public final class ModKeys {
    public static final String CATEGORY = "key.categories.avatarmod";

    public static final KeyMapping CAST = new KeyMapping("key.avatarmod.cast", InputConstants.KEY_R, CATEGORY);
    public static final KeyMapping NEXT = new KeyMapping("key.avatarmod.next", InputConstants.KEY_V, CATEGORY);
    public static final KeyMapping PREVIOUS = new KeyMapping("key.avatarmod.previous", InputConstants.KEY_B, CATEGORY);

    private ModKeys() {}
}
