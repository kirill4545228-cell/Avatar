package com.avatarmod.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;

public final class ModKeys {
    public static final String CATEGORY = "key.categories.avatarmod";

    /** B: меню стихий и способностей. */
    public static final KeyMapping MENU = new KeyMapping("key.avatarmod.menu", InputConstants.KEY_B, CATEGORY);
    /** R: включить или выключить режим покорения. */
    public static final KeyMapping MODE = new KeyMapping("key.avatarmod.mode", InputConstants.KEY_R, CATEGORY);
    /** V / C: следующая и предыдущая способность. */
    public static final KeyMapping NEXT = new KeyMapping("key.avatarmod.next", InputConstants.KEY_V, CATEGORY);
    public static final KeyMapping PREVIOUS = new KeyMapping("key.avatarmod.previous", InputConstants.KEY_C, CATEGORY);

    private ModKeys() {}
}
