package com.avatarmod.client;

import com.avatarmod.entity.EarthBoulderEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Blocks;

/** Рисует вращающийся каменный блок. Позже можно заменить моделью из Blockbench. */
public class EarthBoulderRenderer extends EntityRenderer<EarthBoulderEntity> {

    public EarthBoulderRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(EarthBoulderEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        float spin = (entity.tickCount + partialTick) * 20.0F;
        poseStack.translate(0.0, 0.3, 0.0);
        poseStack.mulPose(Axis.YP.rotationDegrees(spin));
        poseStack.mulPose(Axis.XP.rotationDegrees(spin * 0.7F));
        poseStack.scale(0.7F, 0.7F, 0.7F);
        poseStack.translate(-0.5, -0.5, -0.5);
        Minecraft.getInstance().getBlockRenderer().renderSingleBlock(
                Blocks.STONE.defaultBlockState(), poseStack, buffer, packedLight, OverlayTexture.NO_OVERLAY);
        poseStack.popPose();
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(EarthBoulderEntity entity) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
