package com.avatarmod.client;

import net.minecraft.client.Minecraft;

/** Вызывается из сетевых пакетов только на клиенте. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openMenu() {
        Minecraft.getInstance().setScreen(new BendingScreen());
    }
}
