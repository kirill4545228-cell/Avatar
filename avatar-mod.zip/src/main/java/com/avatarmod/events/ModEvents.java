package com.avatarmod.events;

import com.avatarmod.AvatarMod;
import com.avatarmod.bending.Element;
import com.avatarmod.entity.ElementBossEntity;
import com.avatarmod.entity.ModEntities;
import net.minecraft.world.entity.npc.Villager;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AvatarMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEvents {
    private ModEvents() {}

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        for (Element element : Element.values()) {
            event.put(ModEntities.TEACHERS.get(element).get(), Villager.createAttributes().build());
            event.put(ModEntities.BOSSES.get(element).get(), ElementBossEntity.createAttributes().build());
        }
    }
}
