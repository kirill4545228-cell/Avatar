package com.avatarmod.events;

import com.avatarmod.AvatarMod;
import com.avatarmod.bending.AbilityManager;
import com.avatarmod.bending.ActiveEffects;
import com.avatarmod.bending.BendingData;
import com.avatarmod.bending.ProgressData;
import com.avatarmod.bending.TempBlocks;
import com.avatarmod.command.AvatarCommand;
import com.avatarmod.network.ModNetwork;
import com.avatarmod.network.OpenSelectionPacket;
import com.avatarmod.network.ProgressSync;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber(modid = AvatarMod.MODID)
public final class CommonEvents {
    private CommonEvents() {}

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.level instanceof ServerLevel level) {
            TempBlocks.tick(level);
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            ActiveEffects.tick();
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        BendingData.copy(event.getOriginal(), event.getEntity());
    }

    /** При входе синхронизируем прогресс, а новичку сразу открываем меню выбора стихии. */
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ProgressSync.send(player);
            if (!ProgressData.hasChosen(player)) {
                ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenSelectionPacket());
            }
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ProgressSync.send(player);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        AbilityManager.forget(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        AvatarCommand.register(event.getDispatcher());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        TempBlocks.clear();
        ActiveEffects.clear();
        AbilityManager.clear();
    }
}
