package com.avatarmod.events;

import com.avatarmod.AvatarMod;
import com.avatarmod.bending.AbilityManager;
import com.avatarmod.bending.ActiveEffects;
import com.avatarmod.bending.BendingData;
import com.avatarmod.bending.TempBlocks;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AvatarMod.MODID)
public final class CommonEvents {
    private CommonEvents() {}

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.level instanceof ServerLevel level) {
            TempBlocks.tick(level);
        }
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            ActiveEffects.tick();
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        BendingData.copy(event.getOriginal(), event.getEntity());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        AbilityManager.forget(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        TempBlocks.clear();
        ActiveEffects.clear();
        AbilityManager.clear();
    }
}
