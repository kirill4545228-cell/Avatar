package com.avatarmod.entity;

import com.avatarmod.bending.Abilities;
import com.avatarmod.bending.Ability;
import com.avatarmod.bending.Element;
import com.avatarmod.item.ModItems;
import java.util.List;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.level.Level;

/** Учитель стихии: неподвижный, неуязвимый, продаёт свитки способностей за изумруды. */
public class ElementTeacherEntity extends Villager {
    private static final int[] SCROLL_PRICES = {8, 12, 16, 24, 32};
    private static final int SEAL_PRICE = 16;

    private final Element element;

    public ElementTeacherEntity(EntityType<? extends Villager> type, Level level, Element element) {
        super(type, level);
        this.element = element;
        setNoAi(true);
        setInvulnerable(true);
        setPersistenceRequired();
        setVillagerData(getVillagerData().setProfession(professionFor(element)).setLevel(5));
    }

    public Element getElement() {
        return element;
    }

    private static VillagerProfession professionFor(Element element) {
        return switch (element) {
            case WATER -> VillagerProfession.FISHERMAN;
            case AIR -> VillagerProfession.CLERIC;
            case EARTH -> VillagerProfession.MASON;
            case FIRE -> VillagerProfession.ARMORER;
        };
    }

    @Override
    protected void updateTrades() {
        MerchantOffers offers = getOffers();
        List<Ability> abilities = Abilities.ofElement(element);
        for (int i = 0; i < abilities.size(); i++) {
            int price = SCROLL_PRICES[Math.min(i, SCROLL_PRICES.length - 1)];
            offers.add(new MerchantOffer(
                    new ItemStack(Items.EMERALD, price),
                    new ItemStack(ModItems.scroll(abilities.get(i))),
                    9999, 0, 0.0F));
        }
        offers.add(new MerchantOffer(
                new ItemStack(Items.EMERALD, SEAL_PRICE),
                new ItemStack(ModItems.SEALS.get(element).get()),
                9999, 0, 0.0F));
    }
}
