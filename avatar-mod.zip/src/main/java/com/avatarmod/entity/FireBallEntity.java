package com.avatarmod.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

public class FireBallEntity extends ThrowableProjectile {

    public FireBallEntity(EntityType<? extends FireBallEntity> type, Level level) {
        super(type, level);
    }

    public FireBallEntity(Level level, LivingEntity owner) {
        super(ModEntities.FIRE_BALL.get(), owner, level);
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    protected float getGravity() {
        return 0.005F;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            for (int i = 0; i < 3; i++) {
                level().addParticle(ParticleTypes.FLAME,
                        getX() + random.nextGaussian() * 0.12,
                        getY() + 0.2 + random.nextGaussian() * 0.12,
                        getZ() + random.nextGaussian() * 0.12,
                        0.0, 0.0, 0.0);
            }
            level().addParticle(ParticleTypes.SMOKE, getX(), getY() + 0.2, getZ(), 0.0, 0.0, 0.0);
        } else if (!isRemoved()) {
            if (isInWater()) {
                ((ServerLevel) level()).sendParticles(ParticleTypes.CLOUD, getX(), getY(), getZ(),
                        10, 0.2, 0.2, 0.2, 0.05);
                discard();
            } else if (tickCount > 100) {
                discard();
            }
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        Entity target = result.getEntity();
        target.hurt(level().damageSources().thrown(this, getOwner()), 6.0F);
        target.setSecondsOnFire(5);
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (!level().isClientSide) {
            BlockPos firePos = result.getBlockPos().relative(result.getDirection());
            if (level().getBlockState(firePos).isAir()
                    && BaseFireBlock.canBePlacedAt(level(), firePos, result.getDirection())) {
                level().setBlockAndUpdate(firePos, BaseFireBlock.getState(level(), firePos));
            }
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide) {
            ((ServerLevel) level()).sendParticles(ParticleTypes.FLAME, getX(), getY(), getZ(),
                    40, 0.3, 0.3, 0.3, 0.15);
            level().playSound(null, getX(), getY(), getZ(), SoundEvents.FIRECHARGE_USE,
                    SoundSource.PLAYERS, 1.0F, 0.8F);
            discard();
        }
    }
}
