package com.avatarmod.entity;

import com.avatarmod.AvatarMod;
import com.avatarmod.bending.Element;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AvatarMod.MODID);

    public static final RegistryObject<EntityType<WaterBallEntity>> WATER_BALL = ENTITIES.register("water_ball",
            () -> EntityType.Builder.<WaterBallEntity>of(WaterBallEntity::new, MobCategory.MISC)
                    .sized(0.4F, 0.4F)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build(new ResourceLocation(AvatarMod.MODID, "water_ball").toString()));

    public static final RegistryObject<EntityType<EarthBoulderEntity>> EARTH_BOULDER = ENTITIES.register("earth_boulder",
            () -> EntityType.Builder.<EarthBoulderEntity>of(EarthBoulderEntity::new, MobCategory.MISC)
                    .sized(0.6F, 0.6F)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build(new ResourceLocation(AvatarMod.MODID, "earth_boulder").toString()));

    public static final RegistryObject<EntityType<FireBallEntity>> FIRE_BALL = ENTITIES.register("fire_ball",
            () -> EntityType.Builder.<FireBallEntity>of(FireBallEntity::new, MobCategory.MISC)
                    .sized(0.4F, 0.4F)
                    .fireImmune()
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build(new ResourceLocation(AvatarMod.MODID, "fire_ball").toString()));

    public static final Map<Element, RegistryObject<EntityType<ElementTeacherEntity>>> TEACHERS =
            new EnumMap<>(Element.class);
    public static final Map<Element, RegistryObject<EntityType<ElementBossEntity>>> BOSSES =
            new EnumMap<>(Element.class);

    static {
        for (Element element : Element.values()) {
            String key = element.key();

            TEACHERS.put(element, ENTITIES.register("teacher_" + key,
                    () -> EntityType.Builder.<ElementTeacherEntity>of(
                                    (type, level) -> new ElementTeacherEntity(type, level, element),
                                    MobCategory.MISC)
                            .sized(0.6F, 1.95F)
                            .clientTrackingRange(10)
                            .build(new ResourceLocation(AvatarMod.MODID, "teacher_" + key).toString())));

            BOSSES.put(element, ENTITIES.register("boss_" + key,
                    () -> {
                        EntityType.Builder<ElementBossEntity> builder = EntityType.Builder.<ElementBossEntity>of(
                                        (type, level) -> new ElementBossEntity(type, level, element),
                                        MobCategory.MONSTER)
                                .sized(0.7F, 2.0F)
                                .clientTrackingRange(10);
                        if (element == Element.FIRE) {
                            builder.fireImmune();
                        }
                        return builder.build(new ResourceLocation(AvatarMod.MODID, "boss_" + key).toString());
                    }));
        }
    }

    private ModEntities() {}
}
