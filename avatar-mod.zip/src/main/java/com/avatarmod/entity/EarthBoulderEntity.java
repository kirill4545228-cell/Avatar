package com.avatarmod.entity;

import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class EarthBoulderEntity extends ThrowableProjectile {

    public EarthBoulderEntity(EntityType<? extends EarthBoulderEntity> type, Level level) {
        super(type, level);
    }

    public EarthBoulderEntity(Level level, LivingEntity owner) {
        super(ModEntities.EARTH_BOULDER.get(), owner, level);
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    protected float getGravity() {
        return 0.04F;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            for (int i = 0; i < 2; i++) {
                level().addParticle(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState()),
                        getX() + random.nextGaussian() * 0.2,
                        getY() + 0.2 + random.nextGaussian() * 0.2,
                        getZ() + random.nextGaussian() * 0.2,
                        0.0, 0.0, 0.0);
            }
        } else if (tickCount > 100) {
            discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        Entity target = result.getEntity();
        target.hurt(level().damageSources().thrown(this, getOwner()), 7.0F);
        if (target instanceof LivingEntity living) {
            Vec3 motion = getDeltaMovement();
            living.knockback(0.9, -motion.x, -motion.z);
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide) {
            ((ServerLevel) level()).sendParticles(
                    new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState()),
                    getX(), getY(), getZ(), 30, 0.3, 0.3, 0.3, 0.1);
            level().playSound(null, getX(), getY(), getZ(), SoundEvents.STONE_BREAK,
                    SoundSource.PLAYERS, 1.0F, 0.8F);
            discard();
        }
    }
}
