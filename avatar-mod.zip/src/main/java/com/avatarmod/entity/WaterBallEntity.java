package com.avatarmod.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class WaterBallEntity extends ThrowableProjectile {

    public WaterBallEntity(EntityType<? extends WaterBallEntity> type, Level level) {
        super(type, level);
    }

    public WaterBallEntity(Level level, LivingEntity owner) {
        super(ModEntities.WATER_BALL.get(), owner, level);
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    protected float getGravity() {
        return 0.01F;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            for (int i = 0; i < 4; i++) {
                level().addParticle(ParticleTypes.SPLASH,
                        getX() + random.nextGaussian() * 0.15,
                        getY() + 0.2 + random.nextGaussian() * 0.15,
                        getZ() + random.nextGaussian() * 0.15,
                        0.0, 0.0, 0.0);
            }
            level().addParticle(ParticleTypes.BUBBLE_POP, getX(), getY() + 0.2, getZ(), 0.0, 0.0, 0.0);
        } else if (tickCount > 100) {
            discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        Entity target = result.getEntity();
        target.hurt(level().damageSources().thrown(this, getOwner()), 6.0F);
        target.clearFire();
        if (target instanceof LivingEntity living) {
            Vec3 motion = getDeltaMovement();
            living.knockback(0.6, -motion.x, -motion.z);
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide) {
            ((ServerLevel) level()).sendParticles(ParticleTypes.SPLASH, getX(), getY(), getZ(),
                    40, 0.3, 0.3, 0.3, 0.2);
            level().playSound(null, getX(), getY(), getZ(), SoundEvents.GENERIC_SPLASH,
                    SoundSource.PLAYERS, 1.0F, 1.0F);
            discard();
        }
    }
}
