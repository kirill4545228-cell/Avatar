package com.avatarmod.entity;

import com.avatarmod.bending.Element;
import com.avatarmod.bending.ProgressData;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/** Мастер стихии: небольшой босс. Победа над ним нужна, чтобы открыть следующую стихию. */
public class ElementBossEntity extends Monster {
    private final Element element;
    private final ServerBossEvent bossEvent;
    private int attackTimer = 0;

    public ElementBossEntity(EntityType<? extends ElementBossEntity> type, Level level, Element element) {
        super(type, level);
        this.element = element;
        this.xpReward = 60;
        this.bossEvent = new ServerBossEvent(getDisplayName(), colorFor(element), BossEvent.BossBarOverlay.PROGRESS);
        setPersistenceRequired();
    }

    public Element getElement() {
        return element;
    }

    private static BossEvent.BossBarColor colorFor(Element element) {
        return switch (element) {
            case WATER -> BossEvent.BossBarColor.BLUE;
            case AIR -> BossEvent.BossBarColor.WHITE;
            case EARTH -> BossEvent.BossBarColor.GREEN;
            case FIRE -> BossEvent.BossBarColor.RED;
        };
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 150.0D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.FOLLOW_RANGE, 40.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, false));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(getHealth() / getMaxHealth());

        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) {
            attackTimer = 0;
            return;
        }
        int interval = getHealth() < getMaxHealth() * 0.5F ? 30 : 60;
        if (++attackTimer >= interval) {
            attackTimer = 0;
            float distance = distanceTo(target);
            if (distance >= 3.0F && distance <= 28.0F) {
                rangedAttack(target);
            }
        }
    }

    private void rangedAttack(LivingEntity target) {
        switch (element) {
            case WATER -> shoot(new WaterBallEntity(level(), this), target);
            case FIRE -> shoot(new FireBallEntity(level(), this), target);
            case EARTH -> shoot(new EarthBoulderEntity(level(), this), target);
            case AIR -> gust(target);
        }
    }

    private void shoot(Projectile projectile, LivingEntity target) {
        double dx = target.getX() - getX();
        double dz = target.getZ() - getZ();
        double dy = target.getY(0.33) - projectile.getY();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        projectile.shoot(dx, dy + horizontal * 0.1, dz, 1.4F, 1.5F);
        level().addFreshEntity(projectile);
    }

    /** Воздушный порыв: отбрасывает цель и наносит небольшой урон. */
    private void gust(LivingEntity target) {
        Vec3 away = target.position().subtract(position());
        double length = Math.sqrt(away.x * away.x + away.z * away.z);
        if (length < 1.0E-3) return;
        target.push(away.x / length * 1.4, 0.45, away.z / length * 1.4);
        target.hurtMarked = true;
        target.hurt(damageSources().mobAttack(this), 4.0F);
        if (level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.CLOUD, target.getX(), target.getY() + 1.0, target.getZ(),
                    20, 0.4, 0.5, 0.4, 0.1);
        }
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        bossEvent.setName(getDisplayName());
    }

    @Override
    public boolean removeWhenFarAway(double distanceSqr) {
        return false;
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide) {
            for (ServerPlayer player : bossEvent.getPlayers()) {
                ProgressData.defeatBoss(player, element);
            }
        }
    }
}
