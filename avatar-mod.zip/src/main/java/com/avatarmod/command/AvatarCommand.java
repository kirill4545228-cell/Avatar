package com.avatarmod.command;

import com.avatarmod.bending.Abilities;
import com.avatarmod.bending.Ability;
import com.avatarmod.bending.Element;
import com.avatarmod.bending.ProgressData;
import com.avatarmod.network.ModNetwork;
import com.avatarmod.network.OpenSelectionPacket;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import java.util.Arrays;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

/** Команды для администраторов и тестирования сюжета: /avatar ... */
public final class AvatarCommand {
    private static final SuggestionProvider<CommandSourceStack> ABILITY_IDS = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Abilities.ALL.stream().map(Ability::id), builder);
    private static final SuggestionProvider<CommandSourceStack> ELEMENT_KEYS = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Arrays.stream(Element.values()).map(Element::key), builder);

    private AvatarCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("avatar")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("status").executes(ctx -> status(ctx.getSource())))
                .then(Commands.literal("reset").executes(ctx -> reset(ctx.getSource())))
                .then(Commands.literal("unlockall").executes(ctx -> unlockAll(ctx.getSource())))
                .then(Commands.literal("unlock")
                        .then(Commands.argument("ability", StringArgumentType.word())
                                .suggests(ABILITY_IDS)
                                .executes(ctx -> unlock(ctx.getSource(),
                                        StringArgumentType.getString(ctx, "ability")))))
                .then(Commands.literal("boss")
                        .then(Commands.argument("element", StringArgumentType.word())
                                .suggests(ELEMENT_KEYS)
                                .executes(ctx -> boss(ctx.getSource(),
                                        StringArgumentType.getString(ctx, "element"))))));
    }

    private static int status(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        String text = ProgressData.describe(player);
        source.sendSuccess(() -> Component.literal(text), false);
        return 1;
    }

    private static int reset(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ProgressData.reset(player);
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenSelectionPacket());
        source.sendSuccess(() -> Component.literal("Progress reset"), false);
        return 1;
    }

    private static int unlockAll(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        for (Ability ability : Abilities.ALL) {
            ProgressData.forceLearn(player, ability);
        }
        source.sendSuccess(() -> Component.literal("All abilities unlocked"), false);
        return 1;
    }

    private static int unlock(CommandSourceStack source, String id) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        Ability ability = Abilities.byId(id);
        if (ability == null) {
            source.sendFailure(Component.literal("Unknown ability: " + id));
            return 0;
        }
        ProgressData.forceLearn(player, ability);
        source.sendSuccess(() -> Component.literal("Unlocked: " + id), false);
        return 1;
    }

    private static int boss(CommandSourceStack source, String key) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        Element element = Element.fromKey(key);
        if (element == null) {
            source.sendFailure(Component.literal("Unknown element: " + key));
            return 0;
        }
        ProgressData.defeatBoss(player, element);
        source.sendSuccess(() -> Component.literal("Boss marked as defeated: " + key), false);
        return 1;
    }
}
