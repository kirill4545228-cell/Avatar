package com.avatarmod.item;

import com.avatarmod.bending.Ability;
import com.avatarmod.bending.ProgressData;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Свиток способности: при использовании изучает способность, если это разрешено сюжетом. */
public class AbilityScrollItem extends Item {
    private final Ability ability;

    public AbilityScrollItem(Ability ability, Properties properties) {
        super(properties);
        this.ability = ability;
    }

    public Ability getAbility() {
        return ability;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }

        switch (ProgressData.canLearn(serverPlayer, ability)) {
            case ALREADY_LEARNED ->
                    serverPlayer.displayClientMessage(Component.translatable("message.avatarmod.already_learned"), true);
            case NOT_CHOSEN ->
                    serverPlayer.displayClientMessage(Component.translatable("message.avatarmod.need_choose"), true);
            case LOCKED ->
                    serverPlayer.displayClientMessage(Component.translatable("message.avatarmod.locked_element"), true);
            case OK -> {
                ProgressData.learn(serverPlayer, ability);
                stack.shrink(1);
                level.playSound(null, serverPlayer.getX(), serverPlayer.getY(), serverPlayer.getZ(),
                        SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 1.0F);
                serverPlayer.displayClientMessage(Component.translatable("message.avatarmod.learned",
                        Component.translatable(ability.translationKey())), false);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, false);
    }
}
