package com.avatarmod.item;

import com.avatarmod.bending.Element;
import com.avatarmod.bending.ProgressData;
import com.avatarmod.entity.ElementBossEntity;
import com.avatarmod.entity.ModEntities;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Печать вызова: призывает мастера стихии, если все способности этой стихии изучены. */
public class ChallengeSealItem extends Item {
    private final Element element;

    public ChallengeSealItem(Element element, Properties properties) {
        super(properties);
        this.element = element;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }

        if (!ProgressData.isMastered(serverPlayer, element)) {
            serverPlayer.displayClientMessage(Component.translatable("message.avatarmod.seal_not_mastered"), true);
            return InteractionResultHolder.fail(stack);
        }
        if (ProgressData.isBossDefeated(serverPlayer, element)) {
            serverPlayer.displayClientMessage(Component.translatable("message.avatarmod.boss_already"), true);
            return InteractionResultHolder.fail(stack);
        }

        ServerLevel serverLevel = serverPlayer.serverLevel();
        ElementBossEntity boss = ModEntities.BOSSES.get(element).get().create(serverLevel);
        if (boss == null) return InteractionResultHolder.fail(stack);

        Vec3 look = serverPlayer.getLookAngle();
        double length = Math.sqrt(look.x * look.x + look.z * look.z);
        double dx = length < 1.0E-3 ? 0.0 : look.x / length * 6.0;
        double dz = length < 1.0E-3 ? 0.0 : look.z / length * 6.0;
        boss.moveTo(serverPlayer.getX() + dx, serverPlayer.getY(), serverPlayer.getZ() + dz,
                serverPlayer.getYRot() + 180.0F, 0.0F);
        serverLevel.addFreshEntity(boss);

        stack.shrink(1);
        serverLevel.playSound(null, serverPlayer.getX(), serverPlayer.getY(), serverPlayer.getZ(),
                SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 1.0F, 0.8F);
        return InteractionResultHolder.success(stack);
    }
}
