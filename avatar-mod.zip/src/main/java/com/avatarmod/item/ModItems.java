package com.avatarmod.item;

import com.avatarmod.AvatarMod;
import com.avatarmod.bending.Abilities;
import com.avatarmod.bending.Ability;
import com.avatarmod.bending.Element;
import com.avatarmod.entity.ModEntities;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, AvatarMod.MODID);

    public static final Map<String, RegistryObject<Item>> SCROLLS = new LinkedHashMap<>();
    public static final Map<Element, RegistryObject<Item>> SEALS = new EnumMap<>(Element.class);
    public static final Map<Element, RegistryObject<Item>> TEACHER_EGGS = new EnumMap<>(Element.class);
    public static final Map<Element, RegistryObject<Item>> BOSS_EGGS = new EnumMap<>(Element.class);

    static {
        for (Ability ability : Abilities.ALL) {
            SCROLLS.put(ability.id(), ITEMS.register("scroll_" + ability.id(),
                    () -> new AbilityScrollItem(ability, new Item.Properties().stacksTo(1))));
        }
        for (Element element : Element.values()) {
            int color = colorFor(element);
            SEALS.put(element, ITEMS.register("seal_" + element.key(),
                    () -> new ChallengeSealItem(element, new Item.Properties().stacksTo(1))));
            TEACHER_EGGS.put(element, ITEMS.register("teacher_egg_" + element.key(),
                    () -> new ForgeSpawnEggItem(() -> ModEntities.TEACHERS.get(element).get(),
                            color, 0xFFFFFF, new Item.Properties())));
            BOSS_EGGS.put(element, ITEMS.register("boss_egg_" + element.key(),
                    () -> new ForgeSpawnEggItem(() -> ModEntities.BOSSES.get(element).get(),
                            color, 0x202020, new Item.Properties())));
        }
    }

    private ModItems() {}

    public static Item scroll(Ability ability) {
        return SCROLLS.get(ability.id()).get();
    }

    private static int colorFor(Element element) {
        return switch (element) {
            case WATER -> 0x2E86DE;
            case AIR -> 0xC8D7EB;
            case EARTH -> 0x87643C;
            case FIRE -> 0xE85C1C;
        };
    }
}
