package com.avatarmod.item;

import com.avatarmod.AvatarMod;
import com.avatarmod.bending.Element;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AvatarMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.avatarmod"))
                    .icon(() -> new ItemStack(ModItems.SEALS.get(Element.WATER).get()))
                    .displayItems((parameters, output) -> {
                        for (RegistryObject<Item> item : ModItems.SCROLLS.values()) output.accept(item.get());
                        for (RegistryObject<Item> item : ModItems.SEALS.values()) output.accept(item.get());
                        for (RegistryObject<Item> item : ModItems.TEACHER_EGGS.values()) output.accept(item.get());
                        for (RegistryObject<Item> item : ModItems.BOSS_EGGS.values()) output.accept(item.get());
                    })
                    .build());

    private ModTabs() {}
}
