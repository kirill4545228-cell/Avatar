package com.avatarmod.bending;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Поиск «покоряемой» земли и камня рядом с игроком. */
public final class EarthSource {
    private static final int RADIUS = 5;

    private EarthSource() {}

    public static boolean isBendable(BlockState state) {
        return state.is(BlockTags.BASE_STONE_OVERWORLD)
                || state.is(BlockTags.BASE_STONE_NETHER)
                || state.is(BlockTags.DIRT)
                || state.is(BlockTags.SAND)
                || state.is(BlockTags.TERRACOTTA)
                || state.is(Blocks.COBBLESTONE)
                || state.is(Blocks.GRAVEL)
                || state.is(Blocks.CLAY);
    }

    /** @return состояние ближайшего подходящего блока или null, если рядом нет земли и камня. */
    public static BlockState nearestMaterial(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        BlockPos center = player.blockPosition();
        double limit = (RADIUS + 1) * (RADIUS + 1);
        BlockState best = null;
        double bestDist = Double.MAX_VALUE;

        for (BlockPos pos : BlockPos.betweenClosed(
                center.offset(-RADIUS, -RADIUS - 1, -RADIUS), center.offset(RADIUS, RADIUS, RADIUS))) {
            double dist = pos.distSqr(center);
            if (dist > limit || dist >= bestDist) continue;
            BlockState state = level.getBlockState(pos);
            if (isBendable(state)) {
                best = state;
                bestDist = dist;
            }
        }
        return best;
    }
}
