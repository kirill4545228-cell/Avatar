package com.avatarmod.bending;

import java.util.ArrayList;
import java.util.List;

/** Длящиеся эффекты (воздушный щит, торнадо), которые обновляются каждый тик сервера. */
public final class ActiveEffects {
    public interface Effect {
        /** @return false, когда эффект закончился. */
        boolean tick();
    }

    private static final List<Effect> EFFECTS = new ArrayList<>();

    private ActiveEffects() {}

    public static void add(Effect effect) {
        EFFECTS.add(effect);
    }

    public static void tick() {
        if (EFFECTS.isEmpty()) return;
        EFFECTS.removeIf(effect -> !effect.tick());
    }

    public static void clear() {
        EFFECTS.clear();
    }
}
