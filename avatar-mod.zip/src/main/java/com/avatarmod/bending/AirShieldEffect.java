package com.avatarmod.bending;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** 5 секунд отталкивает существ и отражает снаряды вокруг игрока. */
final class AirShieldEffect implements ActiveEffects.Effect {
    private static final int DURATION = 100;
    private static final double RADIUS = 3.5;

    private final ServerPlayer player;
    private int age = 0;

    AirShieldEffect(ServerPlayer player) {
        this.player = player;
    }

    @Override
    public boolean tick() {
        if (age++ >= DURATION || !player.isAlive() || player.isRemoved()) return false;

        ServerLevel level = player.serverLevel();
        Vec3 center = player.position();

        for (int i = 0; i < 6; i++) {
            double angle = age * 0.35 + i * (Math.PI * 2.0 / 6.0);
            double y = center.y + 0.2 + ((age + i * 7) % 20) * 0.1;
            level.sendParticles(ParticleTypes.CLOUD,
                    center.x + Math.cos(angle) * RADIUS, y, center.z + Math.sin(angle) * RADIUS,
                    1, 0.0, 0.0, 0.0, 0.0);
        }

        AABB box = player.getBoundingBox().inflate(RADIUS, 1.5, RADIUS);
        for (Entity e : level.getEntitiesOfClass(Entity.class, box, t -> t != player && t.isAlive())) {
            Vec3 away = e.position().subtract(center);
            double dist = Math.sqrt(away.x * away.x + away.z * away.z);
            if (dist > RADIUS) continue;
            Vec3 dir = dist < 1.0E-3 ? new Vec3(1.0, 0.0, 0.0) : new Vec3(away.x / dist, 0.0, away.z / dist);

            if (e instanceof Projectile projectile) {
                if (projectile.getOwner() != player) {
                    AirActions.deflect(projectile, new Vec3(dir.x, 0.1, dir.z), player);
                }
            } else if (e instanceof LivingEntity) {
                e.push(dir.x * 0.3, 0.05, dir.z * 0.3);
                e.hurtMarked = true;
            }
        }
        return true;
    }
}
