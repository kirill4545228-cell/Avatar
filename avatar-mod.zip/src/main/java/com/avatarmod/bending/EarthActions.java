package com.avatarmod.bending;

import com.avatarmod.entity.EarthBoulderEntity;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Логика способностей земли. Каждый метод возвращает true, если способность сработала. */
public final class EarthActions {
    private EarthActions() {}

    private static void sound(ServerLevel level, double x, double y, double z, SoundEvent sound, float pitch) {
        level.playSound(null, x, y, z, sound, SoundSource.PLAYERS, 1.0F, pitch);
    }

    private static BlockState material(ServerPlayer player) {
        BlockState state = EarthSource.nearestMaterial(player);
        return state != null ? state : Blocks.STONE.defaultBlockState();
    }

    private static void burst(ServerLevel level, BlockState state, double x, double y, double z,
                              int count, double spread) {
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state),
                x, y, z, count, spread, spread * 0.5, spread, 0.05);
    }

    // ---------------------------------------------------------------- Земляная стена
    public static boolean earthWall(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        BlockState state = material(player);
        if (state.is(Blocks.GRASS_BLOCK) || state.is(Blocks.MYCELIUM) || state.is(Blocks.PODZOL)) {
            state = Blocks.DIRT.defaultBlockState();
        }

        float yaw = player.getYRot() * ((float) Math.PI / 180F);
        double dirX = -Mth.sin(yaw);
        double dirZ = Mth.cos(yaw);
        double centerX = player.getX() + dirX * 3.0;
        double centerZ = player.getZ() + dirZ * 3.0;

        int columns = 0;
        for (int w = -2; w <= 2; w++) {
            double x = centerX - dirZ * w;
            double z = centerZ + dirX * w;
            BlockPos ground = WaterActions.findGround(level, BlockPos.containing(x, player.getY(), z));
            if (ground == null) continue;

            int height = Math.abs(w) == 2 ? 2 : 3;
            for (int h = 0; h < height; h++) {
                BlockPos pos = ground.above(h);
                if (!level.getEntitiesOfClass(LivingEntity.class, new AABB(pos)).isEmpty()) continue;
                TempBlocks.place(level, pos, state, 300);
            }
            burst(level, state, ground.getX() + 0.5, ground.getY() + 0.5, ground.getZ() + 0.5, 12, 0.4);
            columns++;
        }
        if (columns == 0) return false;
        sound(level, centerX, player.getY(), centerZ, SoundEvents.STONE_PLACE, 0.7F);
        return true;
    }

    // ---------------------------------------------------------------- Каменный снаряд
    public static boolean earthBoulder(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        EarthBoulderEntity boulder = new EarthBoulderEntity(level, player);
        boulder.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 1.4F, 0.3F);
        level.addFreshEntity(boulder);
        burst(level, material(player), player.getX(), player.getY() + 0.1, player.getZ(), 15, 0.4);
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.STONE_BREAK, 0.8F);
        return true;
    }

    // ---------------------------------------------------------------- Землетрясение
    public static boolean earthquake(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        BlockState state = material(player);

        AABB box = new AABB(player.getX() - 6.0, player.getY() - 1.5, player.getZ() - 6.0,
                player.getX() + 6.0, player.getY() + 1.5, player.getZ() + 6.0);
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, box,
                t -> t != player && t.isAlive() && t.distanceToSqr(player) <= 49.0);
        for (LivingEntity target : targets) {
            target.hurt(level.damageSources().playerAttack(player), 4.0F);
            target.push(0.0, 0.7, 0.0);
            target.hurtMarked = true;
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1));
        }

        for (int i = 0; i < 24; i++) {
            double angle = i * (Math.PI * 2.0 / 24.0);
            double r = 1.0 + (i % 4) * 1.4;
            burst(level, state, player.getX() + Math.cos(angle) * r, player.getY() + 0.1,
                    player.getZ() + Math.sin(angle) * r, 6, 0.3);
        }
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.GENERIC_EXPLODE, 0.6F);
        return true;
    }

    // ---------------------------------------------------------------- Каменная броня
    public static boolean rockArmor(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 1));
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 200, 1));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 0));
        burst(level, material(player), player.getX(), player.getY() + 1.0, player.getZ(), 40, 0.5);
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.ARMOR_EQUIP_IRON, 0.7F);
        return true;
    }

    // ---------------------------------------------------------------- Земляные оковы
    public static boolean earthShackles(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 start = player.getEyePosition();
        Vec3 dir = player.getLookAngle();
        LivingEntity target = null;

        for (double d = 1.0; d <= 15.0; d += 0.5) {
            Vec3 p = start.add(dir.scale(d));
            BlockPos bp = BlockPos.containing(p);
            if (!level.getBlockState(bp).getCollisionShape(level, bp).isEmpty()) break;

            AABB box = new AABB(p, p).inflate(0.6);
            List<LivingEntity> list = level.getEntitiesOfClass(LivingEntity.class, box,
                    e -> e != player && e.isAlive());
            if (!list.isEmpty()) {
                target = list.get(0);
                break;
            }
        }
        if (target == null) return false;

        target.hurt(level.damageSources().playerAttack(player), 2.0F);
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 6));
        burst(level, material(player), target.getX(), target.getY() + 0.1, target.getZ(), 30, 0.5);
        sound(level, target.getX(), target.getY(), target.getZ(), SoundEvents.STONE_BREAK, 0.6F);
        return true;
    }
}
