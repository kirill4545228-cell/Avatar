package com.avatarmod.bending;

import java.util.Locale;

public enum Element {
    WATER,
    AIR,
    EARTH,
    FIRE;

    public String key() {
        return name().toLowerCase(Locale.ROOT);
    }

    public String translationKey() {
        return "element.avatarmod." + key();
    }

    public static Element fromKey(String key) {
        for (Element element : values()) {
            if (element.key().equalsIgnoreCase(key)) return element;
        }
        return null;
    }
}
