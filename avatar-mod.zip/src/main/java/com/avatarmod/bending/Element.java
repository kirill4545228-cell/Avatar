package com.avatarmod.bending;

public enum Element {
    WATER,
    AIR,
    EARTH,
    FIRE
}
