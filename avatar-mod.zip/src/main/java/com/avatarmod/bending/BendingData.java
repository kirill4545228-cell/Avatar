package com.avatarmod.bending;

import java.util.List;
import net.minecraft.world.entity.player.Player;

public final class BendingData {
    private static final String KEY_SELECTED = "avatarmod_selected";

    private BendingData() {}

    /** В первой версии все игроки владеют всеми стихиями. Позже здесь можно привязать сюжет. */
    public static boolean isBender(Player player, Element element) {
        return true;
    }

    /** @return выбранная способность или null, если игроку недоступна ни одна. */
    public static Ability getSelected(Player player) {
        Ability ability = Abilities.byId(player.getPersistentData().getString(KEY_SELECTED));
        if (ability != null && isBender(player, ability.element())) return ability;
        List<Ability> available = Abilities.available(player);
        return available.isEmpty() ? null : available.get(0);
    }

    public static void cycle(Player player, int direction) {
        List<Ability> available = Abilities.available(player);
        if (available.isEmpty()) return;
        int index = Math.max(0, available.indexOf(getSelected(player)));
        Ability next = available.get(Math.floorMod(index + direction, available.size()));
        player.getPersistentData().putString(KEY_SELECTED, next.id());
    }

    public static void copy(Player from, Player to) {
        if (from.getPersistentData().contains(KEY_SELECTED)) {
            to.getPersistentData().putString(KEY_SELECTED, from.getPersistentData().getString(KEY_SELECTED));
        }
    }
}
