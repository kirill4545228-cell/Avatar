package com.avatarmod.bending;

import java.util.List;
import net.minecraft.world.entity.player.Player;

public final class BendingData {
    private static final String KEY_SELECTED = "avatarmod_selected";

    private BendingData() {}

    /** Стихия открыта, если игрок изучил хотя бы одну её способность. */
    public static boolean isBender(Player player, Element element) {
        return ProgressData.isElementOpen(player, element);
    }

    /** @return выбранная способность или null, если игрок ещё ничего не изучил. */
    public static Ability getSelected(Player player) {
        Ability ability = Abilities.byId(player.getPersistentData().getString(KEY_SELECTED));
        if (ability != null && ProgressData.isUnlocked(player, ability)) return ability;
        List<Ability> available = Abilities.available(player);
        return available.isEmpty() ? null : available.get(0);
    }

    public static void select(Player player, Ability ability) {
        player.getPersistentData().putString(KEY_SELECTED, ability.id());
    }

    public static void cycle(Player player, int direction) {
        List<Ability> available = Abilities.available(player);
        if (available.isEmpty()) return;
        int index = Math.max(0, available.indexOf(getSelected(player)));
        select(player, available.get(Math.floorMod(index + direction, available.size())));
    }

    public static void clearSelected(Player player) {
        player.getPersistentData().remove(KEY_SELECTED);
    }

    public static void copy(Player from, Player to) {
        if (from.getPersistentData().contains(KEY_SELECTED)) {
            to.getPersistentData().putString(KEY_SELECTED, from.getPersistentData().getString(KEY_SELECTED));
        }
        ProgressData.copy(from, to);
    }
}
