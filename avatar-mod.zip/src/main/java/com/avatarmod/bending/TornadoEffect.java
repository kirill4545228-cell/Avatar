package com.avatarmod.bending;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Торнадо на 5 секунд: затягивает, закручивает и поднимает существ рядом. */
final class TornadoEffect implements ActiveEffects.Effect {
    private static final int DURATION = 100;
    private static final double RADIUS = 3.5;
    private static final double HEIGHT = 7.0;

    private final ServerLevel level;
    private final ServerPlayer owner;
    private final Vec3 base;
    private int age = 0;

    TornadoEffect(ServerLevel level, ServerPlayer owner, Vec3 base) {
        this.level = level;
        this.owner = owner;
        this.base = base;
    }

    @Override
    public boolean tick() {
        if (age++ >= DURATION || owner.isRemoved()) return false;

        for (int i = 0; i < 8; i++) {
            double y = (i + (age % 3) / 3.0) * 0.8;
            double radius = 0.4 + y * 0.45;
            double angle = age * 0.5 + y * 1.1;
            level.sendParticles(ParticleTypes.CLOUD,
                    base.x + Math.cos(angle) * radius, base.y + y, base.z + Math.sin(angle) * radius,
                    1, 0.0, 0.0, 0.0, 0.0);
        }

        AABB box = new AABB(base.x - RADIUS, base.y - 1.0, base.z - RADIUS,
                base.x + RADIUS, base.y + HEIGHT, base.z + RADIUS);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, t -> t != owner && t.isAlive())) {
            double dx = base.x - e.getX();
            double dz = base.z - e.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            double nx = dist < 1.0E-3 ? 0.0 : dx / dist;
            double nz = dist < 1.0E-3 ? 0.0 : dz / dist;

            Vec3 v = e.getDeltaMovement();
            e.setDeltaMovement(
                    v.x * 0.5 + nx * 0.08 - nz * 0.14,
                    Math.min(v.y + 0.1, 0.35),
                    v.z * 0.5 + nz * 0.08 + nx * 0.14);
            e.fallDistance = 0.0F;
            e.hurtMarked = true;

            if (age % 20 == 0) {
                e.hurt(level.damageSources().playerAttack(owner), 1.0F);
            }
        }
        return true;
    }
}
