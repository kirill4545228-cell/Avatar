package com.avatarmod.bending;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Логика способностей воздуха. Каждый метод возвращает true, если способность сработала. */
public final class AirActions {
    private AirActions() {}

    private static void sound(ServerLevel level, double x, double y, double z, SoundEvent sound, float pitch) {
        level.playSound(null, x, y, z, sound, SoundSource.PLAYERS, 1.0F, pitch);
    }

    /** Разворачивает снаряд в заданном направлении и делает владельцем заклинателя. */
    static void deflect(Projectile projectile, Vec3 direction, ServerPlayer owner) {
        double speed = Math.max(1.0, projectile.getDeltaMovement().length());
        projectile.setDeltaMovement(direction.normalize().scale(speed));
        projectile.hurtMarked = true;
        projectile.setOwner(owner);
    }

    // ---------------------------------------------------------------- Воздушный порыв
    public static boolean airBlast(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 start = player.getEyePosition();
        Vec3 dir = player.getLookAngle();

        for (double d = 1.0; d <= 8.0; d += 1.0) {
            Vec3 p = start.add(dir.scale(d));
            level.sendParticles(ParticleTypes.CLOUD, p.x, p.y, p.z, 3, d * 0.08, d * 0.08, d * 0.08, 0.02);
        }

        AABB box = new AABB(start, start.add(dir.scale(9.0))).inflate(4.0);
        for (Entity e : level.getEntitiesOfClass(Entity.class, box, t -> t != player && t.isAlive())) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(start);
            double dist = to.length();
            if (dist < 1.0E-3 || dist > 9.0) continue;
            if (to.scale(1.0 / dist).dot(dir) < 0.75) continue;

            if (e instanceof Projectile projectile) {
                if (projectile.getOwner() != player) deflect(projectile, dir, player);
            } else if (e instanceof LivingEntity) {
                double strength = Math.max(0.6, 2.0 - dist * 0.15);
                e.push(dir.x * strength, 0.3, dir.z * strength);
                e.hurtMarked = true;
            }
        }
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.PHANTOM_FLAP, 0.8F);
        return true;
    }

    // ---------------------------------------------------------------- Воздушный рывок
    public static boolean airDash(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 look = player.getLookAngle();
        player.setDeltaMovement(look.x * 1.5, Math.max(look.y * 1.5, 0.35), look.z * 1.5);
        player.hurtMarked = true;
        player.fallDistance = 0.0F;
        player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 60, 0));
        level.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY() + 0.5, player.getZ(),
                20, 0.3, 0.3, 0.3, 0.1);
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.PHANTOM_FLAP, 1.2F);
        return true;
    }

    // ---------------------------------------------------------------- Воздушный прыжок
    public static boolean airJump(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 motion = player.getDeltaMovement();
        player.setDeltaMovement(motion.x, 1.2, motion.z);
        player.hurtMarked = true;
        player.fallDistance = 0.0F;
        player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0));
        level.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY(), player.getZ(),
                25, 0.4, 0.1, 0.4, 0.08);
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.PHANTOM_FLAP, 0.7F);
        return true;
    }

    // ---------------------------------------------------------------- Воздушный щит
    public static boolean airShield(ServerPlayer player) {
        ActiveEffects.add(new AirShieldEffect(player));
        sound(player.serverLevel(), player.getX(), player.getY(), player.getZ(), SoundEvents.PHANTOM_FLAP, 0.5F);
        return true;
    }

    // ---------------------------------------------------------------- Торнадо
    public static boolean tornado(ServerPlayer player) {
        HitResult hit = player.pick(25.0, 1.0F, false);
        if (hit.getType() != HitResult.Type.BLOCK) return false;
        Vec3 base = hit.getLocation();
        ServerLevel level = player.serverLevel();
        ActiveEffects.add(new TornadoEffect(level, player, base));
        sound(level, base.x, base.y, base.z, SoundEvents.PHANTOM_FLAP, 0.5F);
        return true;
    }
}
