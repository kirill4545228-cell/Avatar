package com.avatarmod.bending;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.material.FluidState;

/** Поиск и расход воды: сначала блоки-источники рядом, затем вёдра с водой в инвентаре. */
public final class WaterSource {
    public record Plan(List<BlockPos> blocks, int buckets) {}

    private WaterSource() {}

    /** @return план расхода или null, если воды не хватает. */
    public static Plan plan(ServerPlayer player, int cost) {
        if (cost <= 0 || player.getAbilities().instabuild) {
            return new Plan(List.of(), 0);
        }

        List<BlockPos> found = findSources(player);
        List<BlockPos> used = new ArrayList<>();
        int needed = cost;
        for (BlockPos pos : found) {
            if (needed == 0) break;
            used.add(pos);
            needed--;
        }

        int buckets = 0;
        if (needed > 0) {
            if (countBuckets(player) < needed) return null;
            buckets = needed;
        }
        return new Plan(used, buckets);
    }

    public static void apply(ServerPlayer player, Plan plan) {
        ServerLevel level = player.serverLevel();

        if (BendingConfig.CONSUME_WORLD_WATER) {
            for (BlockPos pos : plan.blocks()) {
                BlockState state = level.getBlockState(pos);
                if (state.getBlock() instanceof LiquidBlock) {
                    level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                } else if (state.hasProperty(BlockStateProperties.WATERLOGGED)) {
                    level.setBlock(pos, state.setValue(BlockStateProperties.WATERLOGGED, false), 3);
                }
            }
        }

        int left = plan.buckets();
        Inventory inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize() && left > 0; i++) {
            if (inv.getItem(i).is(Items.WATER_BUCKET)) {
                inv.setItem(i, new ItemStack(Items.BUCKET));
                left--;
            }
        }
    }

    private static int countBuckets(ServerPlayer player) {
        Inventory inv = player.getInventory();
        int count = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).is(Items.WATER_BUCKET)) count++;
        }
        return count;
    }

    private static List<BlockPos> findSources(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        BlockPos center = player.blockPosition();
        int r = BendingConfig.WATER_SEARCH_RADIUS;
        List<BlockPos> result = new ArrayList<>();

        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-r, -r, -r), center.offset(r, r, r))) {
            if (pos.distSqr(center) > (double) (r * r)) continue;
            if (isConsumable(level, pos)) result.add(pos.immutable());
        }
        result.sort(Comparator.comparingDouble((BlockPos p) -> p.distSqr(center)));
        return result;
    }

    private static boolean isConsumable(ServerLevel level, BlockPos pos) {
        if (TempBlocks.isTemp(level, pos)) return false; // созданная способностью вода не считается источником
        BlockState state = level.getBlockState(pos);
        FluidState fluid = state.getFluidState();
        if (!fluid.is(FluidTags.WATER) || !fluid.isSource()) return false;
        if (state.getBlock() instanceof LiquidBlock) return true;
        return state.hasProperty(BlockStateProperties.WATERLOGGED)
                && state.getValue(BlockStateProperties.WATERLOGGED);
    }
}
