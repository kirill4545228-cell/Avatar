package com.avatarmod.bending;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Полторы секунды струи пламени в сторону взгляда; направление обновляется каждый тик. */
final class FlamethrowerEffect implements ActiveEffects.Effect {
    private static final int DURATION = 30;
    private static final double RANGE = 7.0;

    private final ServerPlayer player;
    private int age = 0;

    FlamethrowerEffect(ServerPlayer player) {
        this.player = player;
    }

    @Override
    public boolean tick() {
        if (age++ >= DURATION || !player.isAlive() || player.isRemoved()) return false;
        if (BendingConfig.FIRE_BLOCKED_BY_WATER && player.isInWaterOrRain()) return false;

        ServerLevel level = player.serverLevel();
        Vec3 start = player.getEyePosition().add(0.0, -0.2, 0.0);
        Vec3 dir = player.getLookAngle();

        for (double d = 1.0; d <= RANGE; d += 0.75) {
            Vec3 p = start.add(dir.scale(d));
            BlockPos bp = BlockPos.containing(p);
            if (!level.getBlockState(bp).getCollisionShape(level, bp).isEmpty()) break;
            double spread = 0.05 + d * 0.06;
            level.sendParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 2, spread, spread, spread, 0.01);
        }

        AABB box = new AABB(start, start.add(dir.scale(RANGE))).inflate(1.5);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, t -> t != player && t.isAlive())) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(start);
            double dist = to.length();
            if (dist < 1.0E-3 || dist > RANGE) continue;
            if (to.scale(1.0 / dist).dot(dir) < 0.85) continue;

            e.setSecondsOnFire(4);
            if (age % 10 == 0) {
                e.hurt(level.damageSources().playerAttack(player), 2.0F);
            }
        }

        if (age % 8 == 1) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 0.6F, 1.5F);
        }
        return true;
    }
}
