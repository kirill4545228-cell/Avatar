package com.avatarmod.bending;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Временные блоки (вода, лёд), которые сами исчезают через заданное число тиков. */
public final class TempBlocks {
    private static final class Entry {
        final Block block;
        final BlockState previous;
        int ticksLeft;

        Entry(Block block, BlockState previous, int ticksLeft) {
            this.block = block;
            this.previous = previous;
            this.ticksLeft = ticksLeft;
        }
    }

    private static final Map<ResourceKey<Level>, Map<BlockPos, Entry>> DATA = new HashMap<>();

    private TempBlocks() {}

    public static boolean isTemp(ServerLevel level, BlockPos pos) {
        Map<BlockPos, Entry> map = DATA.get(level.dimension());
        return map != null && map.containsKey(pos);
    }

    public static boolean place(ServerLevel level, BlockPos pos, BlockState state, int ticks) {
        if (!level.hasChunkAt(pos)) return false;
        BlockState current = level.getBlockState(pos);
        if (!current.canBeReplaced() || current.getFluidState().isSource()) return false;
        if (isTemp(level, pos)) return false;
        level.setBlock(pos, state, 3);
        DATA.computeIfAbsent(level.dimension(), k -> new HashMap<>())
                .put(pos.immutable(), new Entry(state.getBlock(), current, ticks));
        return true;
    }

    public static void tick(ServerLevel level) {
        Map<BlockPos, Entry> map = DATA.get(level.dimension());
        if (map == null || map.isEmpty()) return;

        Iterator<Map.Entry<BlockPos, Entry>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<BlockPos, Entry> e = it.next();
            BlockPos pos = e.getKey();
            Entry entry = e.getValue();
            if (!level.hasChunkAt(pos)) continue;
            if (--entry.ticksLeft > 0) continue;

            it.remove();
            if (level.getBlockState(pos).is(entry.block)) {
                BlockState restore = entry.previous.getFluidState().isEmpty()
                        ? entry.previous : Blocks.AIR.defaultBlockState();
                level.setBlock(pos, restore, 3);
                level.sendParticles(ParticleTypes.SPLASH, pos.getX() + 0.5, pos.getY() + 0.5,
                        pos.getZ() + 0.5, 6, 0.3, 0.3, 0.3, 0.05);
            }
        }
    }

    public static void clear() {
        DATA.clear();
    }
}
