package com.avatarmod.bending;

import com.avatarmod.entity.FireBallEntity;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Логика способностей огня. Каждый метод возвращает true, если способность сработала. */
public final class FireActions {
    private FireActions() {}

    private static void sound(ServerLevel level, double x, double y, double z, SoundEvent sound, float pitch) {
        level.playSound(null, x, y, z, sound, SoundSource.PLAYERS, 1.0F, pitch);
    }

    // ---------------------------------------------------------------- Огненный шар
    public static boolean fireBall(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        FireBallEntity ball = new FireBallEntity(level, player);
        ball.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 1.3F, 0.3F);
        level.addFreshEntity(ball);
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.FIRECHARGE_USE, 1.0F);
        return true;
    }

    // ---------------------------------------------------------------- Огненный поток
    public static boolean flamethrower(ServerPlayer player) {
        ActiveEffects.add(new FlamethrowerEffect(player));
        sound(player.serverLevel(), player.getX(), player.getY(), player.getZ(), SoundEvents.BLAZE_SHOOT, 0.8F);
        return true;
    }

    // ---------------------------------------------------------------- Огненное кольцо
    public static boolean fireRing(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 center = player.position();

        AABB box = player.getBoundingBox().inflate(5.0, 1.5, 5.0);
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, box,
                t -> t != player && t.isAlive() && t.distanceToSqr(player) <= 30.0);
        for (LivingEntity target : targets) {
            Vec3 away = target.position().subtract(center);
            double dist = Math.sqrt(away.x * away.x + away.z * away.z);
            double nx = dist < 1.0E-3 ? 1.0 : away.x / dist;
            double nz = dist < 1.0E-3 ? 0.0 : away.z / dist;
            target.hurt(level.damageSources().playerAttack(player), 4.0F);
            target.setSecondsOnFire(4);
            target.push(nx * 0.9, 0.25, nz * 0.9);
            target.hurtMarked = true;
        }

        for (int ring = 1; ring <= 5; ring++) {
            for (int i = 0; i < 24; i++) {
                double angle = i * (Math.PI * 2.0 / 24.0);
                level.sendParticles(ParticleTypes.FLAME,
                        center.x + Math.cos(angle) * ring, center.y + 0.2, center.z + Math.sin(angle) * ring,
                        1, 0.05, 0.1, 0.05, 0.02);
            }
        }
        sound(level, center.x, center.y, center.z, SoundEvents.BLAZE_SHOOT, 0.6F);
        return true;
    }

    // ---------------------------------------------------------------- Огненный рывок
    public static boolean fireDash(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 look = player.getLookAngle();

        AABB path = player.getBoundingBox().expandTowards(look.scale(4.0)).inflate(1.0);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, path,
                t -> t != player && t.isAlive())) {
            target.hurt(level.damageSources().playerAttack(player), 3.0F);
            target.setSecondsOnFire(3);
        }

        for (double d = 0.0; d <= 4.0; d += 1.0) {
            Vec3 p = player.position().add(look.scale(d));
            level.sendParticles(ParticleTypes.FLAME, p.x, p.y + 1.0, p.z, 8, 0.3, 0.3, 0.3, 0.05);
        }

        player.setDeltaMovement(look.x * 1.4, Math.max(look.y * 1.4, 0.2), look.z * 1.4);
        player.hurtMarked = true;
        player.fallDistance = 0.0F;
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.FIRECHARGE_USE, 1.3F);
        return true;
    }

    // ---------------------------------------------------------------- Молния
    public static boolean lightning(ServerPlayer player) {
        HitResult hit = player.pick(40.0, 1.0F, false);
        if (hit.getType() != HitResult.Type.BLOCK) return false;
        // Не бьём слишком близко, чтобы не попасть по себе.
        if (hit.getLocation().distanceToSqr(player.position()) < 16.0) return false;

        ServerLevel level = player.serverLevel();
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt == null) return false;
        bolt.moveTo(hit.getLocation());
        bolt.setCause(player);
        level.addFreshEntity(bolt);
        return true;
    }
}
