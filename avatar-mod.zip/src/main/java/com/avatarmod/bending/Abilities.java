package com.avatarmod.bending;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.world.entity.player.Player;

/** Список всех способностей в порядке переключения. */
public final class Abilities {
    public static final List<Ability> ALL;

    static {
        List<Ability> list = new ArrayList<>();
        list.addAll(Arrays.asList(WaterAbility.values()));
        list.addAll(Arrays.asList(AirAbility.values()));
        list.addAll(Arrays.asList(EarthAbility.values()));
        list.addAll(Arrays.asList(FireAbility.values()));
        ALL = List.copyOf(list);
    }

    private Abilities() {}

    public static Ability byId(String id) {
        for (Ability ability : ALL) {
            if (ability.id().equals(id)) return ability;
        }
        return null;
    }

    public static List<Ability> ofElement(Element element) {
        List<Ability> result = new ArrayList<>();
        for (Ability ability : ALL) {
            if (ability.element() == element) result.add(ability);
        }
        return result;
    }

    /** Способности, которые игрок уже изучил. */
    public static List<Ability> available(Player player) {
        List<Ability> result = new ArrayList<>();
        for (Ability ability : ALL) {
            if (ProgressData.isUnlocked(player, ability)) result.add(ability);
        }
        return result;
    }
}
