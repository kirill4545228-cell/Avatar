package com.avatarmod.bending;

import com.avatarmod.network.ProgressSync;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/** Сюжетный прогресс игрока: стихии, изученные способности, побеждённые мастера, статус Аватара. */
public final class ProgressData {
    public enum LearnResult { OK, ALREADY_LEARNED, NOT_CHOSEN, LOCKED }

    private static final String ROOT = "avatarmod_progress";
    private static final String START = "start";
    private static final String ABILITIES = "abilities";
    private static final String BOSSES = "bosses";
    private static final String AVATAR = "avatar";

    private ProgressData() {}

    private static CompoundTag root(Player player) {
        CompoundTag data = player.getPersistentData();
        if (!data.contains(ROOT, Tag.TAG_COMPOUND)) {
            data.put(ROOT, new CompoundTag());
        }
        return data.getCompound(ROOT);
    }

    private static Set<String> readSet(Player player, String key) {
        Set<String> result = new HashSet<>();
        ListTag list = root(player).getList(key, Tag.TAG_STRING);
        for (int i = 0; i < list.size(); i++) {
            result.add(list.getString(i));
        }
        return result;
    }

    private static void addToSet(Player player, String key, String value) {
        CompoundTag root = root(player);
        ListTag list = root.getList(key, Tag.TAG_STRING);
        for (int i = 0; i < list.size(); i++) {
            if (list.getString(i).equals(value)) return;
        }
        list.add(StringTag.valueOf(value));
        root.put(key, list);
    }

    // ------------------------------------------------------------ состояние
    public static boolean hasChosen(Player player) {
        return root(player).contains(START, Tag.TAG_STRING);
    }

    public static boolean isUnlocked(Player player, Ability ability) {
        return readSet(player, ABILITIES).contains(ability.id());
    }

    public static int learnedCount(Player player, Element element) {
        Set<String> learned = readSet(player, ABILITIES);
        int count = 0;
        for (Ability ability : Abilities.ofElement(element)) {
            if (learned.contains(ability.id())) count++;
        }
        return count;
    }

    public static boolean isElementOpen(Player player, Element element) {
        return learnedCount(player, element) > 0;
    }

    public static boolean isMastered(Player player, Element element) {
        return learnedCount(player, element) >= Abilities.ofElement(element).size();
    }

    public static boolean isBossDefeated(Player player, Element element) {
        return readSet(player, BOSSES).contains(element.name());
    }

    public static boolean isAvatar(Player player) {
        return root(player).getBoolean(AVATAR);
    }

    /** Новую стихию можно открыть, только если все открытые освоены, а их мастера побеждены. */
    public static boolean canOpenNewElement(Player player) {
        for (Element element : Element.values()) {
            if (isElementOpen(player, element)
                    && !(isMastered(player, element) && isBossDefeated(player, element))) {
                return false;
            }
        }
        return true;
    }

    // ------------------------------------------------------------ действия
    /** Выбор стартовой стихии при первом появлении. Даёт первую способность этой стихии. */
    public static boolean choose(Player player, Element element) {
        if (hasChosen(player)) return false;
        root(player).putString(START, element.name());
        addToSet(player, ABILITIES, Abilities.ofElement(element).get(0).id());
        sync(player);
        return true;
    }

    public static LearnResult canLearn(Player player, Ability ability) {
        if (isUnlocked(player, ability)) return LearnResult.ALREADY_LEARNED;
        if (!hasChosen(player)) return LearnResult.NOT_CHOSEN;
        if (isElementOpen(player, ability.element())) return LearnResult.OK;
        return canOpenNewElement(player) ? LearnResult.OK : LearnResult.LOCKED;
    }

    public static void learn(Player player, Ability ability) {
        addToSet(player, ABILITIES, ability.id());
        checkAvatar(player);
        sync(player);
    }

    /** Для команд администратора: учит способность без проверок. */
    public static void forceLearn(Player player, Ability ability) {
        if (!hasChosen(player)) {
            root(player).putString(START, ability.element().name());
        }
        learn(player, ability);
    }

    public static void defeatBoss(ServerPlayer player, Element element) {
        addToSet(player, BOSSES, element.name());
        player.displayClientMessage(Component.translatable("message.avatarmod.boss_defeated",
                Component.translatable(element.translationKey())), false);
        checkAvatar(player);
        sync(player);
    }

    private static void sync(Player player) {
        if (player instanceof ServerPlayer serverPlayer) {
            ProgressSync.send(serverPlayer);
        }
    }

    private static void checkAvatar(Player player) {
        if (isAvatar(player)) return;
        for (Element element : Element.values()) {
            if (!isMastered(player, element) || !isBossDefeated(player, element)) return;
        }
        root(player).putBoolean(AVATAR, true);
        if (player instanceof ServerPlayer serverPlayer) {
            serverPlayer.displayClientMessage(Component.translatable("message.avatarmod.avatar"), false);
        }
    }

    public static void reset(Player player) {
        player.getPersistentData().remove(ROOT);
        BendingData.clearSelected(player);
        sync(player);
    }

    public static void copy(Player from, Player to) {
        CompoundTag data = from.getPersistentData();
        if (data.contains(ROOT, Tag.TAG_COMPOUND)) {
            to.getPersistentData().put(ROOT, data.getCompound(ROOT).copy());
        }
    }

    public static String describe(Player player) {
        return "start=" + root(player).getString(START)
                + ", abilities=" + readSet(player, ABILITIES)
                + ", bosses=" + readSet(player, BOSSES)
                + ", avatar=" + isAvatar(player);
    }
}
