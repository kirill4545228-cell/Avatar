package com.avatarmod.bending;

public final class BendingConfig {
    private BendingConfig() {}

    /** Радиус поиска воды вокруг игрока (в блоках). */
    public static final int WATER_SEARCH_RADIUS = 8;

    /** true: использованный блок-источник пропадает. false: вода нужна рядом, но не тратится. */
    public static final boolean CONSUME_WORLD_WATER = true;

    /** Магия воздуха работает, только если уровень сытости выше этого значения (макс. 20). */
    public static final int AIR_MIN_FOOD = 6;

    /** Магия огня работает, только если уровень сытости выше этого значения (макс. 20). */
    public static final int FIRE_MIN_FOOD = 6;

    /** true: огонь не работает, пока игрок в воде или под дождём. */
    public static final boolean FIRE_BLOCKED_BY_WATER = true;
}
