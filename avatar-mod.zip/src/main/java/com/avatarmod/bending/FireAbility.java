package com.avatarmod.bending;

import java.util.function.Predicate;
import net.minecraft.server.level.ServerPlayer;

public enum FireAbility implements Ability {
    FIRE_BALL("fire_ball", 1.5F, 25, FireActions::fireBall),
    FLAMETHROWER("flamethrower", 2.5F, 120, FireActions::flamethrower),
    FIRE_RING("fire_ring", 3.0F, 160, FireActions::fireRing),
    FIRE_DASH("fire_dash", 1.5F, 60, FireActions::fireDash),
    LIGHTNING("lightning", 6.0F, 600, FireActions::lightning);

    private final String id;
    private final float exhaustion;
    private final int cooldownTicks;
    private final Predicate<ServerPlayer> action;

    FireAbility(String id, float exhaustion, int cooldownTicks, Predicate<ServerPlayer> action) {
        this.id = id;
        this.exhaustion = exhaustion;
        this.cooldownTicks = cooldownTicks;
        this.action = action;
    }

    @Override
    public Element element() {
        return Element.FIRE;
    }

    @Override
    public String id() {
        return id;
    }

    @Override
    public String translationKey() {
        return "ability.avatarmod." + id;
    }

    @Override
    public int cooldownTicks() {
        return cooldownTicks;
    }

    @Override
    public String missingResourceKey() {
        return "message.avatarmod.no_fire";
    }

    /** Огню нужны силы (сытость) и сухая погода: в воде и под дождём он не горит. */
    @Override
    public Runnable prepare(ServerPlayer player) {
        if (player.getAbilities().instabuild) return () -> { };
        if (BendingConfig.FIRE_BLOCKED_BY_WATER && player.isInWaterOrRain()) return null;
        if (player.getFoodData().getFoodLevel() <= BendingConfig.FIRE_MIN_FOOD) return null;
        return () -> player.causeFoodExhaustion(exhaustion);
    }

    @Override
    public boolean use(ServerPlayer player) {
        return action.test(player);
    }
}
