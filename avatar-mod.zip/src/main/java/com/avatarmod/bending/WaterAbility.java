package com.avatarmod.bending;

import java.util.function.Predicate;
import java.util.function.ToIntFunction;
import net.minecraft.server.level.ServerPlayer;

public enum WaterAbility implements Ability {
    WATER_WHIP("water_whip", p -> 1, 15, WaterActions::waterWhip),
    WATER_BALL("water_ball", p -> 1, 25, WaterActions::waterBall),
    WATER_CONTROL("water_control", p -> p.isShiftKeyDown() ? 0 : 1, 30, WaterActions::waterControl),
    ICE_SPIKES("ice_spikes", p -> 2, 60, WaterActions::iceSpikes),
    HEALING("healing", p -> 3, 200, WaterActions::healing);

    private final String id;
    private final ToIntFunction<ServerPlayer> cost;
    private final int cooldownTicks;
    private final Predicate<ServerPlayer> action;

    WaterAbility(String id, ToIntFunction<ServerPlayer> cost, int cooldownTicks, Predicate<ServerPlayer> action) {
        this.id = id;
        this.cost = cost;
        this.cooldownTicks = cooldownTicks;
        this.action = action;
    }

    @Override
    public Element element() {
        return Element.WATER;
    }

    @Override
    public String id() {
        return id;
    }

    @Override
    public String translationKey() {
        return "ability.avatarmod." + id;
    }

    @Override
    public int cooldownTicks() {
        return cooldownTicks;
    }

    @Override
    public String missingResourceKey() {
        return "message.avatarmod.no_water";
    }

    /** Сколько единиц воды (источников или вёдер) стоит применение. */
    public int cost(ServerPlayer player) {
        return cost.applyAsInt(player);
    }

    @Override
    public Runnable prepare(ServerPlayer player) {
        WaterSource.Plan plan = WaterSource.plan(player, cost(player));
        if (plan == null) return null;
        return () -> WaterSource.apply(player, plan);
    }

    @Override
    public boolean use(ServerPlayer player) {
        return action.test(player);
    }
}
