package com.avatarmod.bending;

import java.util.function.Predicate;
import net.minecraft.server.level.ServerPlayer;

public enum AirAbility implements Ability {
    AIR_BLAST("air_blast", 1.0F, 20, AirActions::airBlast),
    AIR_DASH("air_dash", 1.5F, 40, AirActions::airDash),
    AIR_JUMP("air_jump", 1.5F, 40, AirActions::airJump),
    AIR_SHIELD("air_shield", 3.0F, 200, AirActions::airShield),
    TORNADO("tornado", 4.0F, 300, AirActions::tornado);

    private final String id;
    private final float exhaustion;
    private final int cooldownTicks;
    private final Predicate<ServerPlayer> action;

    AirAbility(String id, float exhaustion, int cooldownTicks, Predicate<ServerPlayer> action) {
        this.id = id;
        this.exhaustion = exhaustion;
        this.cooldownTicks = cooldownTicks;
        this.action = action;
    }

    @Override
    public Element element() {
        return Element.AIR;
    }

    @Override
    public String id() {
        return id;
    }

    @Override
    public String translationKey() {
        return "ability.avatarmod." + id;
    }

    @Override
    public int cooldownTicks() {
        return cooldownTicks;
    }

    @Override
    public String missingResourceKey() {
        return "message.avatarmod.no_stamina";
    }

    /** Воздух тратит выносливость: нужна сытость выше порога, способность добавляет усталость. */
    @Override
    public Runnable prepare(ServerPlayer player) {
        if (player.getAbilities().instabuild) return () -> { };
        if (player.getFoodData().getFoodLevel() <= BendingConfig.AIR_MIN_FOOD) return null;
        return () -> player.causeFoodExhaustion(exhaustion);
    }

    @Override
    public boolean use(ServerPlayer player) {
        return action.test(player);
    }
}
