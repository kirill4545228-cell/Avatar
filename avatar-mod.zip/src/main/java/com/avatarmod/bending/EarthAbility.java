package com.avatarmod.bending;

import java.util.function.Predicate;
import net.minecraft.server.level.ServerPlayer;

public enum EarthAbility implements Ability {
    EARTH_WALL("earth_wall", 60, EarthActions::earthWall),
    EARTH_BOULDER("earth_boulder", 30, EarthActions::earthBoulder),
    EARTHQUAKE("earthquake", 100, EarthActions::earthquake),
    ROCK_ARMOR("rock_armor", 400, EarthActions::rockArmor),
    EARTH_SHACKLES("earth_shackles", 120, EarthActions::earthShackles);

    private final String id;
    private final int cooldownTicks;
    private final Predicate<ServerPlayer> action;

    EarthAbility(String id, int cooldownTicks, Predicate<ServerPlayer> action) {
        this.id = id;
        this.cooldownTicks = cooldownTicks;
        this.action = action;
    }

    @Override
    public Element element() {
        return Element.EARTH;
    }

    @Override
    public String id() {
        return id;
    }

    @Override
    public String translationKey() {
        return "ability.avatarmod." + id;
    }

    @Override
    public int cooldownTicks() {
        return cooldownTicks;
    }

    @Override
    public String missingResourceKey() {
        return "message.avatarmod.no_earth";
    }

    /** Земля ничего не тратит, но рядом должна быть земля или камень. */
    @Override
    public Runnable prepare(ServerPlayer player) {
        if (player.getAbilities().instabuild) return () -> { };
        if (EarthSource.nearestMaterial(player) == null) return null;
        return () -> { };
    }

    @Override
    public boolean use(ServerPlayer player) {
        return action.test(player);
    }
}
