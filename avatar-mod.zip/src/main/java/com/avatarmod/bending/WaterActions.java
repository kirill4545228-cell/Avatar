package com.avatarmod.bending;

import com.avatarmod.entity.WaterBallEntity;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Логика всех способностей воды. Каждый метод возвращает true, если способность сработала. */
public final class WaterActions {
    private WaterActions() {}

    private static void sound(ServerLevel level, double x, double y, double z, SoundEvent sound, float pitch) {
        level.playSound(null, x, y, z, sound, SoundSource.PLAYERS, 1.0F, pitch);
    }

    // ---------------------------------------------------------------- Водяной кнут
    public static boolean waterWhip(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 start = player.getEyePosition();
        Vec3 dir = player.getLookAngle();
        LivingEntity hit = null;

        for (double d = 1.0; d <= 12.0; d += 0.5) {
            Vec3 p = start.add(dir.scale(d));
            BlockPos bp = BlockPos.containing(p);
            if (!level.getBlockState(bp).getCollisionShape(level, bp).isEmpty()) break;

            level.sendParticles(ParticleTypes.SPLASH, p.x, p.y, p.z, 4, 0.1, 0.1, 0.1, 0.0);
            level.sendParticles(ParticleTypes.BUBBLE, p.x, p.y, p.z, 1, 0.05, 0.05, 0.05, 0.0);

            AABB box = new AABB(p, p).inflate(0.6);
            List<LivingEntity> list = level.getEntitiesOfClass(LivingEntity.class, box,
                    e -> e != player && e.isAlive());
            if (!list.isEmpty()) {
                hit = list.get(0);
                break;
            }
        }

        if (hit != null) {
            hit.hurt(level.damageSources().playerAttack(player), 6.0F);
            hit.push(dir.x * 0.8, 0.3, dir.z * 0.8);
            hit.hurtMarked = true;
            hit.clearFire();
        }
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.PLAYER_SPLASH, 1.4F);
        return true;
    }

    // ---------------------------------------------------------------- Водяной шар
    public static boolean waterBall(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        WaterBallEntity ball = new WaterBallEntity(level, player);
        ball.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 1.6F, 0.5F);
        level.addFreshEntity(ball);
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.PLAYER_SPLASH, 1.0F);
        return true;
    }

    // ---------------------------------------------------------------- Управление водой
    /** Обычное применение: создаёт временную воду. С Shift: убирает воду вокруг цели. */
    public static boolean waterControl(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        boolean drain = player.isShiftKeyDown();

        HitResult hit = player.pick(20.0, 1.0F, drain);
        if (hit.getType() != HitResult.Type.BLOCK) return false;
        BlockHitResult blockHit = (BlockHitResult) hit;

        if (drain) {
            BlockPos center = blockHit.getBlockPos();
            int removed = 0;
            for (BlockPos pos : BlockPos.betweenClosed(center.offset(-3, -3, -3), center.offset(3, 3, 3))) {
                BlockState state = level.getBlockState(pos);
                if (state.getBlock() instanceof LiquidBlock && state.getFluidState().is(FluidTags.WATER)) {
                    level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                    if (removed < 20) {
                        level.sendParticles(ParticleTypes.SPLASH, pos.getX() + 0.5, pos.getY() + 0.5,
                                pos.getZ() + 0.5, 5, 0.3, 0.3, 0.3, 0.05);
                    }
                    removed++;
                }
            }
            if (removed == 0) return false;
            sound(level, center.getX(), center.getY(), center.getZ(), SoundEvents.BUCKET_FILL, 1.0F);
            return true;
        }

        BlockPos base = blockHit.getBlockPos().relative(blockHit.getDirection());
        BlockPos[] spots = {base, base.north(), base.south(), base.east(), base.west()};
        int placed = 0;
        for (BlockPos pos : spots) {
            if (TempBlocks.place(level, pos, Blocks.WATER.defaultBlockState(), 200)) placed++;
        }
        if (placed == 0) return false;
        sound(level, base.getX(), base.getY(), base.getZ(), SoundEvents.BUCKET_EMPTY, 1.0F);
        return true;
    }

    // ---------------------------------------------------------------- Ледяные шипы
    public static boolean iceSpikes(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        float yaw = player.getYRot() * ((float) Math.PI / 180F);
        double dirX = -Mth.sin(yaw);
        double dirZ = Mth.cos(yaw);

        Set<LivingEntity> damaged = new HashSet<>();
        int made = 0;

        for (int i = 2; i <= 9; i++) {
            BlockPos start = BlockPos.containing(player.getX() + dirX * i, player.getY(), player.getZ() + dirZ * i);
            BlockPos ground = findGround(level, start);
            if (ground == null) continue;

            int height = 2 + (i % 3);
            AABB box = new AABB(ground).inflate(0.6, 0.0, 0.6).expandTowards(0.0, height, 0.0);
            for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, box,
                    t -> t != player && t.isAlive())) {
                if (damaged.add(target)) {
                    target.hurt(level.damageSources().playerAttack(player), 5.0F);
                    target.push(0.0, 0.6, 0.0);
                    target.hurtMarked = true;
                    target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 2));
                    target.setTicksFrozen(target.getTicksRequiredToFreeze() + 60);
                }
            }

            for (int h = 0; h < height; h++) {
                BlockPos pos = ground.above(h);
                if (!level.getEntitiesOfClass(LivingEntity.class, new AABB(pos)).isEmpty()) continue;
                TempBlocks.place(level, pos, Blocks.PACKED_ICE.defaultBlockState(), 100);
            }
            level.sendParticles(ParticleTypes.SNOWFLAKE, ground.getX() + 0.5, ground.getY() + 1.0,
                    ground.getZ() + 0.5, 10, 0.3, 0.5, 0.3, 0.02);
            made++;
        }

        if (made == 0) return false;
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.GLASS_BREAK, 0.8F);
        return true;
    }

    static BlockPos findGround(ServerLevel level, BlockPos from) {
        for (int dy = 2; dy >= -4; dy--) {
            BlockPos pos = from.offset(0, dy, 0);
            BlockPos below = pos.below();
            if (level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)
                    && level.getBlockState(pos).canBeReplaced()) {
                return pos;
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- Исцеление
    public static boolean healing(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        AABB area = player.getBoundingBox().inflate(6.0);
        List<Player> targets = level.getEntitiesOfClass(Player.class, area, p -> p.isAlive());

        boolean anyNeedsHealing = false;
        for (Player p : targets) {
            if (p.getHealth() < p.getMaxHealth()) {
                anyNeedsHealing = true;
                break;
            }
        }
        if (!anyNeedsHealing) return false;

        for (Player p : targets) {
            p.heal(8.0F);
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
            p.clearFire();
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1.0, p.getZ(),
                    12, 0.4, 0.6, 0.4, 0.02);
            level.sendParticles(ParticleTypes.SPLASH, p.getX(), p.getY() + 1.0, p.getZ(),
                    20, 0.4, 0.6, 0.4, 0.1);
        }
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.BREWING_STAND_BREW, 1.2F);
        return true;
    }
}
