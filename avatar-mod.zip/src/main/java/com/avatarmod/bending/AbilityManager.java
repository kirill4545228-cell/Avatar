package com.avatarmod.bending;

import com.avatarmod.network.ProgressSync;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/** Серверная логика: выбор способности, перезарядка, проверка и трата ресурсов. */
public final class AbilityManager {
    private static final Map<UUID, Map<String, Long>> COOLDOWNS = new HashMap<>();

    private AbilityManager() {}

    public static void select(ServerPlayer player, int direction) {
        if (Abilities.available(player).isEmpty()) {
            player.displayClientMessage(Component.translatable("message.avatarmod.no_abilities"), true);
            return;
        }
        BendingData.cycle(player, direction);
        ProgressSync.send(player);
        Ability selected = BendingData.getSelected(player);
        if (selected == null) return;
        player.displayClientMessage(Component.translatable("message.avatarmod.selected",
                Component.translatable(selected.translationKey())), true);
    }

    public static void cast(ServerPlayer player) {
        if (player.isSpectator() || !player.isAlive()) return;

        Ability ability = BendingData.getSelected(player);
        if (ability == null) {
            player.displayClientMessage(Component.translatable("message.avatarmod.no_abilities"), true);
            return;
        }

        long now = player.level().getGameTime();
        Map<String, Long> map = COOLDOWNS.computeIfAbsent(player.getUUID(), k -> new HashMap<>());

        long readyAt = map.getOrDefault(ability.id(), 0L);
        if (now < readyAt) {
            long seconds = (readyAt - now + 19) / 20;
            player.displayClientMessage(Component.translatable("message.avatarmod.cooldown", seconds), true);
            return;
        }

        Runnable payment = ability.prepare(player);
        if (payment == null) {
            player.displayClientMessage(Component.translatable(ability.missingResourceKey()), true);
            return;
        }

        if (!ability.use(player)) {
            player.displayClientMessage(Component.translatable("message.avatarmod.cant_use"), true);
            return;
        }

        payment.run();
        map.put(ability.id(), now + ability.cooldownTicks());
    }

    public static void forget(UUID id) {
        COOLDOWNS.remove(id);
    }

    public static void clear() {
        COOLDOWNS.clear();
    }
}
