package com.avatarmod.bending;

import net.minecraft.server.level.ServerPlayer;

/** Общий интерфейс способности любой стихии. */
public interface Ability {
    Element element();

    /** Уникальный id, например "water_ball". Хранится в данных игрока. */
    String id();

    String translationKey();

    int cooldownTicks();

    /** Ключ сообщения, если ресурса не хватает. */
    String missingResourceKey();

    /**
     * Проверяет ресурсы (вода, сытость и т.п.).
     * @return действие, которое спишет ресурсы после успешного применения, или null, если ресурсов не хватает.
     */
    Runnable prepare(ServerPlayer player);

    /** @return true, если способность сработала. */
    boolean use(ServerPlayer player);
}
