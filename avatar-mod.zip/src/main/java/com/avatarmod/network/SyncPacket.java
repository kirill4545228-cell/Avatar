package com.avatarmod.network;

import com.avatarmod.client.ClientProgress;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Сервер -> клиент: состояние прогресса игрока. */
public class SyncPacket {
    private final boolean chosen;
    private final boolean avatar;
    private final List<String> unlocked;
    private final String selected;
    private final List<String> bosses;

    public SyncPacket(boolean chosen, boolean avatar, List<String> unlocked, String selected, List<String> bosses) {
        this.chosen = chosen;
        this.avatar = avatar;
        this.unlocked = unlocked;
        this.selected = selected;
        this.bosses = bosses;
    }

    private static void writeList(FriendlyByteBuf buf, List<String> list) {
        buf.writeVarInt(list.size());
        for (String value : list) {
            buf.writeUtf(value);
        }
    }

    private static List<String> readList(FriendlyByteBuf buf) {
        int size = buf.readVarInt();
        List<String> list = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            list.add(buf.readUtf());
        }
        return list;
    }

    public static void encode(SyncPacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.chosen);
        buf.writeBoolean(msg.avatar);
        writeList(buf, msg.unlocked);
        buf.writeUtf(msg.selected);
        writeList(buf, msg.bosses);
    }

    public static SyncPacket decode(FriendlyByteBuf buf) {
        boolean chosen = buf.readBoolean();
        boolean avatar = buf.readBoolean();
        List<String> unlocked = readList(buf);
        String selected = buf.readUtf();
        List<String> bosses = readList(buf);
        return new SyncPacket(chosen, avatar, unlocked, selected, bosses);
    }

    public static void handle(SyncPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientProgress.apply(msg.chosen, msg.avatar, msg.unlocked, msg.selected, msg.bosses)));
        ctx.setPacketHandled(true);
    }
}
