package com.avatarmod.network;

import com.avatarmod.bending.Abilities;
import com.avatarmod.bending.Ability;
import com.avatarmod.bending.BendingData;
import com.avatarmod.bending.ProgressData;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Клиент -> сервер: выбрать конкретную способность в меню. */
public class SelectAbilityPacket {
    private final String id;

    public SelectAbilityPacket(String id) {
        this.id = id;
    }

    public static void encode(SelectAbilityPacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.id);
    }

    public static SelectAbilityPacket decode(FriendlyByteBuf buf) {
        return new SelectAbilityPacket(buf.readUtf());
    }

    public static void handle(SelectAbilityPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) return;
            Ability ability = Abilities.byId(msg.id);
            if (ability == null || !ProgressData.isUnlocked(player, ability)) return;
            BendingData.select(player, ability);
            ProgressSync.send(player);
            player.displayClientMessage(Component.translatable("message.avatarmod.selected",
                    Component.translatable(ability.translationKey())), true);
        });
        ctx.setPacketHandled(true);
    }
}
