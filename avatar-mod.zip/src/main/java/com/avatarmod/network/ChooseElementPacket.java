package com.avatarmod.network;

import com.avatarmod.bending.Element;
import com.avatarmod.bending.ProgressData;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Клиент -> сервер: выбор стартовой стихии. */
public class ChooseElementPacket {
    private final Element element;

    public ChooseElementPacket(Element element) {
        this.element = element;
    }

    public static void encode(ChooseElementPacket msg, FriendlyByteBuf buf) {
        buf.writeEnum(msg.element);
    }

    public static ChooseElementPacket decode(FriendlyByteBuf buf) {
        return new ChooseElementPacket(buf.readEnum(Element.class));
    }

    public static void handle(ChooseElementPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) return;
            if (ProgressData.choose(player, msg.element)) {
                player.displayClientMessage(Component.translatable("message.avatarmod.chosen",
                        Component.translatable(msg.element.translationKey())), false);
            }
        });
        ctx.setPacketHandled(true);
    }
}
