package com.avatarmod.network;

import com.avatarmod.bending.AbilityManager;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

public class AbilityPacket {
    public enum Action { CAST, NEXT, PREVIOUS }

    private final Action action;

    public AbilityPacket(Action action) {
        this.action = action;
    }

    public static void encode(AbilityPacket msg, FriendlyByteBuf buf) {
        buf.writeEnum(msg.action);
    }

    public static AbilityPacket decode(FriendlyByteBuf buf) {
        return new AbilityPacket(buf.readEnum(Action.class));
    }

    public static void handle(AbilityPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) return;
            switch (msg.action) {
                case CAST -> AbilityManager.cast(player);
                case NEXT -> AbilityManager.select(player, 1);
                case PREVIOUS -> AbilityManager.select(player, -1);
            }
        });
        ctx.setPacketHandled(true);
    }
}
