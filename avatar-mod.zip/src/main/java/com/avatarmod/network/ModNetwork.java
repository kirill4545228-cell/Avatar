package com.avatarmod.network;

import com.avatarmod.AvatarMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "2";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(AvatarMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private ModNetwork() {}

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, AbilityPacket.class,
                AbilityPacket::encode, AbilityPacket::decode, AbilityPacket::handle);
        CHANNEL.registerMessage(id++, ChooseElementPacket.class,
                ChooseElementPacket::encode, ChooseElementPacket::decode, ChooseElementPacket::handle);
        CHANNEL.registerMessage(id++, SelectAbilityPacket.class,
                SelectAbilityPacket::encode, SelectAbilityPacket::decode, SelectAbilityPacket::handle);
        CHANNEL.registerMessage(id++, OpenSelectionPacket.class,
                OpenSelectionPacket::encode, OpenSelectionPacket::decode, OpenSelectionPacket::handle);
        CHANNEL.registerMessage(id++, SyncPacket.class,
                SyncPacket::encode, SyncPacket::decode, SyncPacket::handle);
    }
}
