package com.avatarmod.network;

import com.avatarmod.bending.Abilities;
import com.avatarmod.bending.Ability;
import com.avatarmod.bending.BendingData;
import com.avatarmod.bending.Element;
import com.avatarmod.bending.ProgressData;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

/** Отправляет клиенту актуальное состояние прогресса (для меню и HUD). */
public final class ProgressSync {
    private ProgressSync() {}

    public static void send(ServerPlayer player) {
        List<String> unlocked = new ArrayList<>();
        for (Ability ability : Abilities.available(player)) {
            unlocked.add(ability.id());
        }
        Ability selected = BendingData.getSelected(player);
        List<String> bosses = new ArrayList<>();
        for (Element element : Element.values()) {
            if (ProgressData.isBossDefeated(player, element)) bosses.add(element.name());
        }
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new SyncPacket(ProgressData.hasChosen(player), ProgressData.isAvatar(player),
                        unlocked, selected == null ? "" : selected.id(), bosses));
    }
}
