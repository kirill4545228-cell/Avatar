package com.avatarmod.network;

import com.avatarmod.client.ClientHooks;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Сервер -> клиент: открыть меню стихий. */
public class OpenSelectionPacket {
    public static void encode(OpenSelectionPacket msg, FriendlyByteBuf buf) {
    }

    public static OpenSelectionPacket decode(FriendlyByteBuf buf) {
        return new OpenSelectionPacket();
    }

    public static void handle(OpenSelectionPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openMenu()));
        ctx.setPacketHandled(true);
    }
}
